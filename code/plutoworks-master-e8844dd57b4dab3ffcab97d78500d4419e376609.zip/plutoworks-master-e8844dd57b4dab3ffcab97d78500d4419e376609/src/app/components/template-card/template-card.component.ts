import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { HttpClient, HttpHandler, HttpHeaders } from '@angular/common/http';
import { ElectronService } from '../../providers/electron.service';
import { ToastrService } from 'ngx-toastr';
import { gitClone } from '../../utils/git';
import { vAlert, vPrompt } from '../../utils/vex';
import { Project } from '../../model/project';
import { ProjectService } from '../../providers/project.service';
import { httpGet } from '../../utils/http';

@Component({
  selector: 'app-template-card',
  templateUrl: './template-card.component.html',
  styleUrls: [
    './template-card.component.scss'
  ]
})
export class TemplateCardComponent implements OnInit {
  @Input() url: string;
  template: any;
  public loading = false;

  constructor(public http: HttpClient,
              public electronService: ElectronService,
              public toastr: ToastrService,
              public projectService: ProjectService,
  ) {
  }

  ngOnInit() {
    this.getTemplate();
  }

  getTemplate() {
    httpGet(this.url)
      .then(res => res.data)
      .then(data => this.template = data['template'])
      .catch(err => this.toastr.error(err.toString()));
  }

  onClick(source) {
    const documentPath = this.electronService.remote.app.getPath('documents');
    vPrompt('使用下面地址初始化项目', documentPath, v => {
      if (v) {
        this.loading = true;
        const targetPath = v.charAt(0) === '/' ? v : this.electronService.path.join(documentPath, v);

        gitClone(source.git.url, targetPath, source.git.branch, false).then(
          (result) => {
            this.loading = false;
            this.toastr.success(result, '创建成功');
            console.log(new Project(result));
            this.projectService.insertOne(new Project(result));
          },
          (err) => {
            this.loading = false;
            this.toastr.error(err);
          }
        );
      }
    });
  }
}
