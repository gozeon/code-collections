const rimraf = window.require('rimraf');

export function remove(path: string, callback?: () => void): void {
  rimraf(path, function () {
    if (callback) {
      callback();
    }
  });
}

