import { Component, OnInit } from '@angular/core';
import { PlanetService } from '../../providers/planet.service';
import { Planet } from '../../model/planet';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-setting',
  templateUrl: './setting.component.html',
  styleUrls: ['./setting.component.scss']
})
export class SettingComponent {
  myForm: FormGroup;
  planets: Planet[];

  constructor(public planetService: PlanetService, public fb: FormBuilder) {
    this.myForm = fb.group({
      'name': ['', Validators.required],
      'url': ['', Validators.required],
    });

    this.initData();
  }

  initData() {
   this.planets = this.planetService.getAll();
  }

  onSubmit(v) {
    this.planetService.insertOne(new Planet(v.name, v.url));
    this.initData();
  }

  deleteById(id: string) {
    this.planetService.deleteById(id);
    this.initData();
  }
}
