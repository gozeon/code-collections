import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { existsFile, readYaml } from '../../utils/fs';
import { ElectronService } from '../../providers/electron.service';
import { PlanetService } from '../../providers/planet.service';

@Component({
  selector: 'app-check-pluto-yml',
  templateUrl: './check-pluto-yml.component.html',
  styleUrls: ['./check-pluto-yml.component.scss']
})
export class CheckPlutoYmlComponent implements OnChanges {
  @Input() path: string;

  constructor(public electronService: ElectronService,
              public planetService: PlanetService) {
  }

  ngOnChanges(changes: SimpleChanges) {
    const p = changes['path'].currentValue;
  }

  existPlutoYml(path: string) {
    if (existsFile(path, 'pluto.yml')) {
      return false;
    } else {
      return 'no pluto.yml';
    }
  }

  checkContent(path: string) {
    const ymlPath = this.electronService.path.join(path, 'pluto.yml');

    if (readYaml(ymlPath)) {
      return false;
    } else {
      return 'pluto.yml is empty or wrong format';
    }
  }

  checkType(path: string) {
    const ymlPath = this.electronService.path.join(path, 'pluto.yml');
    const yml = readYaml(ymlPath);
    
    if (yml.type && (this.planetService.getAll().map(i => i.name).indexOf(yml.type) !== -1)) {
      return false;
    } else {
      return 'Type is null or nonexistent';
    }
  }


}
