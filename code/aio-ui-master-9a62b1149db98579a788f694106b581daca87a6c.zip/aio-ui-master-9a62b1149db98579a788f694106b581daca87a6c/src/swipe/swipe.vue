<style src="./swipe.scss" lang="scss"> </style>
