const axios = window.require('axios');
axios.defaults.adapter = window.require('axios/lib/adapters/http');

export function httpGet(url: string) {
  return axios.get(url);
}
