# dialog

这是两个 dialog 组件

1.  dialog 询问框

2.  alert 提示框
