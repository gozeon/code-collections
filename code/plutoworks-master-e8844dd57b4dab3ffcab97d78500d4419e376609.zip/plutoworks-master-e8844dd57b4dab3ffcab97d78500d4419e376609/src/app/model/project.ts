import {generateId} from '../utils/id';

export class Project {
  id: string;
  name: string;
  path: string;

  constructor(_path: string, _name?: string) {
    this.id = generateId();
    this.name = _name ? _name : _path.split('/')[_path.split('/').length - 1];
    this.path = _path;
  }
}
