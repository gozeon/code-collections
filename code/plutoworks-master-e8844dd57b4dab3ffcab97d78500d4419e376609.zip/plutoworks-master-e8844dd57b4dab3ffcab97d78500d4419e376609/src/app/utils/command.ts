import {remove} from './rm';
import {xterm} from './xterm';

const os = window.require('os');
const {join} = window.require('path');
const pty = window.require('node-pty');
const ps = window.require('ps-node');
const execa = window.require('execa');
const path = window.require('path');
const fixPath = window.require('fix-path');
fixPath();

// The pty process needs to be run in its own child process to get around maxing out CPU on Mac,
// see https://github.com/electron/electron/issues/38
let shellName: string;
if (os.platform() === 'win32') {
  shellName = path.basename(process.env.PTYSHELL);
} else {
  // Using 'xterm-256color' here helps ensure that the majority of Linux distributions will use a
  // color prompt as defined in the default ~/.bashrc file.
  shellName = 'xterm-color';
}

function cleanEnv() {
  const keys = [
    'AMD_ENTRYPOINT',
    'ELECTRON_NO_ASAR',
    'ELECTRON_RUN_AS_NODE',
    'GOOGLE_API_KEY',
    'PTYCWD',
    'PTYPID',
    'PTYSHELL',
    'PTYCOLS',
    'PTYROWS',
    'PTYSHELLCMDLINE',
    'VSCODE_LOGS',
    'VSCODE_PORTABLE',
    'VSCODE_PID',
  ];
  keys.forEach(function (key) {
    if (process.env[key]) {
      delete process.env[key];
    }
  });
  let i = 0;
  while (process.env['PTYSHELLARG' + i]) {
    delete process.env['PTYSHELLARG' + i];
    i++;
  }
}

cleanEnv();

// class Pty {
//   pty: any;
//
//   constructor(cmd: string, args: string[], ops: any) {
//     const shell = process.env[os.platform() === 'win32' ? 'COMSPEC' : 'SHELL'];
//
//     this.pty = pty.spawn(shell, [], Object.assign({}, {
//       name: 'xterm-color',
//       cols: 100,
//       rows: 30,
//     }, ops));
//
//     this._log();
//
//     const s = `${cmd} ${args.join(' ')} \r`;
//     this.pty.write(s);
//
//   }
//
//   _log() {
//     this.pty.on('data', function (data) {
//       xterm.write(data);
//     });
//   }
// }

class Pty {
  pty: any;

  constructor(cmd: string, args: string[], ops: any) {
    this.pty = pty.spawn(cmd, args, Object.assign({}, {
      name: 'xterm-color',
      cols: 100,
      rows: 30,
    }, ops));

    this._log();
  }

  _log() {
    this.pty.on('data', function (data) {
      xterm.write(data);
    });
  }
}

// class Pty {
//   pty;
//
//   constructor(cmd: string, args: string[], ops: any) {
//     this.pty = execa(cmd, args, ops);
//
//     this._log();
//   }
//
//   _log() {
//     this.pty.stdout.on('data', data => xterm.write(data.toString().replace(/\r?\n/g, '\r\n')));
//     this.pty.stderr.on('data', data => xterm.write(data.toString().replace(/\r?\n/g, '\r\n')));
//   }
// }

export const clear: string = os.platform() === 'win32' ? 'cls\r' : 'clear\r';

export function commonTask(task: string[]) {
  return task.join(' && ') + '\r';
}

export function installModules(cwd: string, isReInstall = false) {
  if (isReInstall) {
    remove(join(cwd, 'node_modules'));
  }

  return new Pty('npm', ['install'], {cwd: cwd});
}

export function runScripts(name: string, cwd: string) {
  return new Pty('npm', ['run', name], {cwd: cwd});
}
