import { setStyle } from "../util";

export class Swipe {
  constructor(options) {
    this._swipe = options.element;
    this._interval = options.interval || 3000;
    this._speed = options.speed || 10;
    this._container = this._swipe.querySelector(".container");
    this._defaultLength = this._container.children.length;
    this._width = this._swipe.clientWidth;
    this._height = this._swipe.clientHeight;
    this._animated = false;
    this._index = 1;
    this._timer = null;
    this._start = {};
    this._move = {};

    // 首尾插入点
    this._container.insertBefore(
      this._container.children[this._container.children.length - 1].cloneNode(
        true
      ),
      this._container.children[0]
    );
    this._container.appendChild(this._container.children[1].cloneNode(true));

    // 计算样式
    setStyle(this._container, {
      width: `${this._container.children.length * this._width}px`,
      height: `${this._height}px`,
      position: "absolute",
      zIndex: 1,
      left: `-${this._width}px`
    });

    for (let i = 0; i < this._container.children.length; i++) {
      setStyle(this._container.children[i], {
        height: `${this._height}px`,
        width: `${this._width}px`,
        float: "left"
      });
    }

    // button group
    this._btnGroup = document.createElement("div");
    this._btnGroup.classList.add("aio-btn-group");
    for (let i = 0; i < this._defaultLength; i++) {
      const btn = document.createElement("span");
      this._btnGroup.appendChild(btn);
    }
    this._btnGroup.children[this._index - 1].classList.add("on");
    this._swipe.appendChild(this._btnGroup);

    // touch 事件
    this._container.addEventListener(
      "touchstart",
      e => this._handleStart(e),
      false
    );
    this._container.addEventListener(
      "touchmove",
      e => this._handleMove(e),
      false
    );
    this._container.addEventListener(
      "touchend",
      e => this._handleEnd(e),
      false
    );
  }

  _animate(offset, container, defaultLength, interval, animated, width) {
    if (offset == 0) {
      return;
    }
    animated = true;
    let time = 300;
    let speed = offset / (time / interval);
    let left = parseInt(container.style.left) + offset;

    let go = function() {
      if (
        (speed > 0 && parseInt(container.style.left) < left) ||
        (speed < 0 && parseInt(container.style.left) > left)
      ) {
        container.style.left = parseInt(container.style.left) + speed + "px";
        setTimeout(go, interval);
      } else {
        container.style.left = left + "px";
        if (left > -width) {
          container.style.left = -width * defaultLength + "px";
        }
        if (left < -width * defaultLength) {
          container.style.left = -width + "px";
        }
        animated = false;
      }
    };
    go();
  }

  _buttonGroupStyle() {
    for (let i = 0; i < this._defaultLength; i++) {
      this._btnGroup.children[i].classList.remove("on");
    }
    this._btnGroup.children[this._index - 1].classList.add("on");
  }

  _run(offset) {
    this._animate(
      offset,
      this._container,
      this._defaultLength,
      this._speed,
      this._animated,
      this._width
    );
    this._buttonGroupStyle();
  }

  _handleStart(e) {
    e.preventDefault();
    this.stop();

    this._start.pageX = e.touches[0].pageX;
    this._start.pageY = e.touches[0].pageY;
  }

  _handleMove(e) {
    e.preventDefault();
    this._move.pageX = e.touches[0].pageX;
    this._move.pageY = e.touches[0].pageY;
    this._container.style.left =
      -this._index * this._width +
      parseInt(this._move.pageX - this._start.pageX) +
      "px";
  }

  _handleEnd(e) {
    e.preventDefault();
    if (isNaN(this._move.pageX - this._start.pageX)) {
      this.play();
      return;
    }
    const distance = parseInt(this._move.pageX - this._start.pageX);
    if (Math.abs(distance) > this._width / 5) {
      if (distance > 0) {
        // 手指向右滑动
        this.prev(distance);
      }
      if (distance < 0) {
        // 手指向左滑动
        this.next(distance);
      }
    } else {
      // 恢复原位
      this._container.style.left =
        parseInt(this._container.style.left) - distance + "px";
    }

    this.play();
  }

  play() {
    this._timer = setTimeout(() => {
      this.next();
      this.play();
    }, this._interval);
  }

  stop() {
    clearTimeout(this._timer);
  }

  next(offset = 0) {
    if (this._animated) {
      return;
    }
    if (this._index == this._defaultLength) {
      this._index = 1;
    } else {
      this._index += 1;
    }
    this._run(-this._width - offset);
  }

  prev(offset = 0) {
    if (this._animated) {
      return;
    }
    if (this._index == 1) {
      this._index = this._defaultLength;
    } else {
      this._index -= 1;
    }
    this._run(this._width - offset);
  }

  show(index) {
    if ((index < 0) | (index > this._defaultLength)) {
      throw new Error("超出元素范围");
    }
    if (index === this._index) {
      return;
    }
    const offset = -this._width * (index - this._index);
    this._index = index;
    this._run(offset);
  }
}
