import {Injectable} from '@angular/core';
import {Planet} from '../model/planet';

interface UpdatePlanetOptions {
  name?: string;
  url?: string;
}

@Injectable()
export class PlanetService {

  constructor() {
  }

  insertOne(planet: Planet) {
    const oldData = this._get();

    if (oldData.map(i => i.name).indexOf(planet.name) !== -1) {
      return;
    }

    oldData.unshift(planet);
    this._save(oldData);
  }

  getAll() {
    return this._get();
  }

  updateById(id: string, options: UpdatePlanetOptions) {
    return this._get().map(item => {
      if (item.id === id) {
        return Object.assign({}, item, options, {id: id});
      }
      return item;
    });
  }

  deleteById(id: string) {
    const data = this._get().filter(item => item.id !== id);
    this._save(data);
  }

  exist(name: string): boolean {
    if (!name) {
      return false;
    }
    return this._get().map(i => i.name).indexOf(name) !== -1;
  }

  findOneByName(name: string): Planet {
    if (this.exist(name)) {
      return this._get().find(o => o.name === name);
    }
    return null;
  }

  _save(arr: any[]) {
    localStorage.setItem('planet', JSON.stringify(arr));
  }

  _get() {
    return JSON.parse(localStorage.getItem('planet')) || [];
  }
}
