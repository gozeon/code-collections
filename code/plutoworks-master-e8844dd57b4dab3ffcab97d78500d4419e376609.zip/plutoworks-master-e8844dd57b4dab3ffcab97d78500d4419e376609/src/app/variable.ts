export const DEFAULT_COMPONENT_PATH = 'src/components';
export const CHECK_VERSION_URL = 'http://test.office.jiedaibao.com/plutoworks/package.json';
export const DOWNLOAD_URL = 'http://test.office.jiedaibao.com/plutoworks';
export const CHECKING_NETWORK_URL = 'http://www.baidu.com/';
export const COMPONENT_TEMP = '.pluto';
