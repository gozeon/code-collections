import {enableProdMode} from '@angular/core';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';

import {AppModule} from './app/app.module';
import {AppConfig} from './environments/environment';
import {CHECKING_NETWORK_URL} from './app/variable';

if (AppConfig.production) {
  enableProdMode();
}

Offline.options = {
  request: false
};

Offline.options = {checks: {xhr: {url: CHECKING_NETWORK_URL}}};
Offline.check();

platformBrowserDynamic()
  .bootstrapModule(AppModule, {
    preserveWhitespaces: false
  })
  .catch(err => console.error(err));
