import template from "./template.html";
import { generateUID, TemplateEngine, getTranslate } from "../util";

export class Picker {
  /**
   * @param options
   * {
   *    data: [[any, any, any, ...]],
   *    cancel: (value) => void
   *    submit: (value) => void
   * }
   */
  constructor(options) {
    this._data = options.data;
    this._id = `aioPicker${generateUID()}`;
    document.body.insertAdjacentHTML(
      "beforeend",
      TemplateEngine(template, { list: this._data, id: this._id })
    );
    this._picker = document.querySelector(`#${this._id}`);
    this._mask = this._picker.querySelector(".aio-mask");
    this._container = this._picker.querySelector(".container");
    this._btnCancel = this._container.querySelector(".btn-group .btn-cancel");
    this._btnSubmit = this._container.querySelector(".btn-group .btn-submit");
    this._content = this._container.querySelector(".content");
    this._list = this._content.querySelectorAll(".list");
    this._indicator = this._content.querySelector(".indicator");
    this._defaultHieght = this._indicator.getBoundingClientRect().height;
    this._defaultTop = this._indicator.offsetTop - this._defaultHieght / 2;
    this._indexGroup = [];

    this._init(options);
  }

  _init(options) {
    this._picker.style.display = "none";

    // list 设置宽度，取消会自适应，影响touch事件范围
    for (let i = 0; i < this._list.length; i++) {
      this._list[i].style.width = `${document.documentElement.clientWidth /
        this._list.length}px`;
    }

    if (options.defaultValue) {
      this.setValue(options.defaultValue);
    } else {
      for (let j = 0; j < this._list.length; j++) {
        this._indexGroup[j] = Math.round(this._list[j].children.length / 2);
      }
    }

    // default value
    this._setIndex(this._indexGroup);

    let start = {};
    let move = {};
    let defaultTop = 0;
    let itemIndex = 0;
    let diffY = 0;

    this._content.addEventListener(
      "touchstart",
      e => {
        e.preventDefault();

        start.pageX = e.touches[0].pageX;
        start.pageY = e.touches[0].pageY;
        itemIndex = parseInt(
          start.pageX /
            (document.documentElement.clientWidth / this._list.length)
        );
        defaultTop = getTranslate(this._list[itemIndex])[1];
      },
      false
    );

    this._content.addEventListener(
      "touchmove",
      e => {
        e.preventDefault();

        move.pageX = e.touches[0].pageX;
        move.pageY = e.touches[0].pageY;

        diffY = parseInt(move.pageY - start.pageY);
        this._list[itemIndex].style.transform = `translateY(${defaultTop +
          diffY}px)`;

        // 计算index
        this._indexGroup[itemIndex] = Math.round(
          (this._defaultTop - getTranslate(this._list[itemIndex])[1]) /
            this._defaultHieght +
            1
        );

        if (
          this._indexGroup[itemIndex] > this._list[itemIndex].children.length
        ) {
          this._indexGroup[itemIndex] = this._list[itemIndex].children.length;
        }
        if (this._indexGroup[itemIndex] <= 0) {
          // 0 < -0 false
          this._indexGroup[itemIndex] = 1;
        }

        this._setWheelStyle();
      },
      false
    );

    this._content.addEventListener(
      "touchend",
      e => {
        e.preventDefault();

        if (!diffY) {
          // Y轴没动
          return;
        }
        // 第一种方法，加上剩下未移动的
        // let restY = this._defaultHieght - Math.abs(diffY);
        // if(diffY > 0) {
        //   list[0].style.transform = `translateY(${getTranslate(list[0])[1] + restY}px)`;
        // }
        //
        // if(diffY < 0) {
        //   list[0].style.transform = `translateY(${getTranslate(list[0])[1] - restY}px)`;
        // }

        /**
         * 第二种方法，使用index
         * @attention 动态修改样式，所以放到move事件，end事件做最后的位移和callback
         */
        // this._indexGroup[itemIndex] = Math.round(
        //   (this._defaultTop - getTranslate(this._list[itemIndex])[1]) /
        //     this._defaultHieght +
        //     1
        // );
        //
        // if (
        //   this._indexGroup[itemIndex] > this._list[itemIndex].children.length
        // ) {
        //   this._indexGroup[itemIndex] = this._list[itemIndex].children.length;
        // }
        // if (this._indexGroup[itemIndex] <= 0) {
        //   // 0 < -0 false
        //   this._indexGroup[itemIndex] = 1;
        // }

        this._list[itemIndex].style.transform = `translateY(${this._defaultTop -
          (this._indexGroup[itemIndex] - 1) * this._defaultHieght}px`;

        if (options.changed) {
          options.changed(
            Object.keys(this._data)[itemIndex],
            this.getValue()[itemIndex],
            (key, data, defaultValue) => this._setDate(key, data, defaultValue)
          );
        }
      },
      false
    );

    this._btnCancel.addEventListener(
      "touchstart",
      e => {
        e.preventDefault();
        this.hide();

        if (options.cancel) {
          options.cancel(this.getValue());
        }
      },
      false
    );

    this._btnSubmit.addEventListener(
      "touchstart",
      e => {
        e.preventDefault();
        this.hide();

        if (options.submit) {
          options.submit(this.getValue());
        }
      },
      false
    );
  }

  /**
   * list 滚轮的样式
   * @private
   */
  _setWheelStyle() {
    const ROTATE_X_ANGLE = ["14.5deg", "30deg", "48.6deg", "70deg"];
    const SCALE_X = [0.98, 0.96, 0.94, 0.92];
    const TRANSLATE_Z = ["-12px", "-18px", "-30px", "-42px"];

    this._indexGroup.forEach((item, index) => {
      this._list[index].children[item - 1].style.transform = "unset";
      for (let i = item; i < item + 4; i++) {
        const ascending = i;
        const descending = 2 * item - i - 2;
        const step = i - item;

        if (this._list[index].children[ascending]) {
          this._list[index].children[
            ascending
          ].style.transform = `rotateX(-${14 * (step + 1)}deg)`;
        }
        if (this._list[index].children[descending]) {
          this._list[index].children[
            descending
          ].style.transform = `rotateX(${14 * (step + 1)}deg)`;
        }
      }
    });
  }

  /**
   * @param index [number, number, number, ...]
   * @private
   */
  _setIndex(index) {
    index.forEach((item, index) => {
      this._list[index].style.transform = `translateY(${this._defaultTop -
        (+item - 1) * this._defaultHieght}px`;
    });

    this._indexGroup = index;
    this._setWheelStyle();
  }

  _setDate(key, data, defaultValue) {
    let index = Object.keys(this._data).findIndex(function(element) {
      return element == key;
    });
    if (index < 0) {
      throw new Error(`参数 ${key} 不存在`);
    }
    if (!Array.isArray(data) || data.length <= 0) {
      throw new Error(`data is not a array or length <= 0`);
    }

    const htmlTpl = `
    <% for(let j = 1; j <= this.list.length; j++ ) { %>
      <div class="item" data-index="<% j %>" data-value="<% this.list[j-1]['value'] %>"><% this.list[j-1]['name'] %></div>
    <% } %>
    `;

    this._list[index].innerHTML = TemplateEngine(htmlTpl, { list: data });

    if (this._indexGroup[index] > data.length) {
      this._indexGroup[index] = data.length;
    }

    if (defaultValue) {
      let value = this.getValue();
      value[index] = defaultValue;
      this.setValue(value);
    }
  }

  /**
   * @param value [any, any, any, ...]
   */
  setValue(value) {
    let indexs = [];

    for (let i = 0; i < this._list.length; i++) {
      for (let j = 0; j < this._list[i].children.length; j++) {
        if (this._list[i].children[j].getAttribute("data-value") == value[i]) {
          indexs[i] = +this._list[i].children[j].getAttribute("data-index");
        }
      }
    }
    this._setIndex(indexs);
  }

  getValue() {
    let result = [];

    for (let i = 0; i < this._list.length; i++) {
      result.push(
        this._list[i].children[this._indexGroup[i] - 1].getAttribute(
          "data-value"
        )
      );
    }

    return result;
  }

  show() {
    this._picker.style.display = "block";
    this._mask.classList.remove("aio-animate-fade-out");
    this._mask.classList.add("aio-animate-fade-in");

    this._container.classList.remove("aio-animate-slide-down");
    this._container.classList.add("aio-animate-slide-up");
  }

  hide() {
    this._mask.classList.add("aio-animate-fade-out");
    this._mask.classList.remove("aio-animate-fade-in");

    this._container.classList.add("aio-animate-slide-down");
    this._container.classList.remove("aio-animate-slide-up");
  }
}
