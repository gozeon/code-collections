export interface Tab {
  tabTitle: string;
  selected?: boolean;
}
