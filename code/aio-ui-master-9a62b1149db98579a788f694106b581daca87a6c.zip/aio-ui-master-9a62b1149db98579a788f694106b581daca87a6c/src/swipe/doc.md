# swipe

### TODO

* [] 组件高度和底部 button 效果优化
* [] 计时器优化(页面跳转回来会有问题)
* [] options 增加方向、loop
* [] 监听事件 on
* [] play() 参数增加方向、时间间隔、速度、loop

### 如何使用

html

```html
<div id="swipe" class="swipe">
  <div class="container">       <!-- require -->
    <!-- any tags -->
    <!-- 节点数作为页面数 -->
    ...
  </div>
</div>
```

css

```css
.swipe {
  height: 200px; /* require */
  overflow: hidden; /* options */
  position: relative; /* require */
}
```

ES Module

```js
Vue.use(AioUI);
var app = new Vue({
  el: "#vue",
  data: {
    message: "AIO Swipe"
  },
  mounted() {
    const swipe = new this.$AIOSwipe({
      element: document.querySelector("#swipe"),
      interval: 3000, // default 3000
      speed: 10 // default 10  300/speed
    });
    swipe.play();
  }
});
```

<script\>

```js
var swipe = new Vue.AIOSwipe({
  element: document.querySelector("#swipe"),
  interval: 3000, // default 3000
  speed: 10 // default 10  300/speed
});
swipe.play();
```

### API

<details>
<summary>new Vue.AIOSwipe(options)</summary>
_初始化一个swipe_  

| Parameters | Types   | Required | Default | Description                 |
| ---------- | ------- | -------- | ------- | --------------------------- |
| element    | Element | Yes      |         | 元素根结点                  |
| interval   | Number  | No       | 3000    | 切换时间间隔，单位(ms)      |
| speed      | Number  | No       | 10      |  切换速度， 公式(300/speed) |

</details>

<details>
<summary>Instances.play()</summary>
_开始自动向滚动，默认方向左侧_
</details>

<details>
<summary>Instances.next()</summary>
_显示前一个页面_
</details>

<details>
<summary>Instances.prev()</summary>
_显示下一个页面_
</details>

<details>
<summary>Instances.show(index)</summary>
_开始自动向滚动，默认方向左侧_  

| Parameters | Types  | Required | Default | Description                                    |
| ---------- | ------ | -------- | ------- | ---------------------------------------------- |
| index      | Number | Yes      |         | 要显示的页面的  序号，范围(1 < index < length) |

</details>

### 其他

项目 & 文档问题和建议请发送邮件 pluto.list@jiedaibao.com
