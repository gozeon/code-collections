# toast

这是两个 toast 组件

1.  toastText 纯文字

2.  toastIcon 文字带图标
