const {BrowserWindow, ipcRenderer} = window.require('electron');
const {download} = window.require('electron-dl');

export function d(ops): any {
  const element = document.createElement('a');
  element.setAttribute('download', ops.url);
  element.style.display = 'none';
  document.body.appendChild(element);
  element.click();
  document.body.removeChild(element);


  return new Promise((resolve, reject) => {
    ipcRenderer.send('download', ops);

    ipcRenderer.on('download-complete', (e, file) => {
      resolve(file);
    });

    ipcRenderer.on('download-error', (e, error) => {
      reject(error);
    });
  });

}
