import {Component, Input, OnInit} from '@angular/core';
import {DEFAULT_COMPONENT_PATH} from '../../variable';
import {getDirectories} from '../../utils/fs';
import {ElectronService} from '../../providers/electron.service';
import {tooltip} from '../../utils/tooltip';
import {ModalService} from '../dialog/dialog.component';
import {generateId} from '../../utils/id';
import {Project} from '../../model/project';
import {PlanetService} from '../../providers/planet.service';

@Component({
  selector: 'app-component-manager',
  templateUrl: './component-manager.component.html',
  styleUrls: ['./component-manager.component.scss']
})
export class ComponentManagerComponent implements OnInit {
  @Input() path: string;
  @Input() plutoConfig: any;

  componentPath = DEFAULT_COMPONENT_PATH;
  modalId = generateId();

  constructor(public electronService: ElectronService,
              public modalService: ModalService,
              public planetService: PlanetService) {
  }

  ngOnInit() {
    tooltip('.tooltip');
  }

  getComponents(path: string) {
    const cpath = this.plutoConfig.component.path || this.componentPath;
    const p = this.electronService.path.join(path, cpath);
    return getDirectories(p);
  }

  openFolder(path: string) {
    this.electronService.remote.shell.openItem(path);
  }

  openModal(id: string) {
    this.modalService.open(id);
  }

  closeModal(id: string) {
    this.modalService.close(id);
  }

  checkTemplateName(name): boolean {
    return this.planetService.exist(name);
  }

  getUrl(name) {
    return this.planetService.findOneByName(name).url;
  }
}
