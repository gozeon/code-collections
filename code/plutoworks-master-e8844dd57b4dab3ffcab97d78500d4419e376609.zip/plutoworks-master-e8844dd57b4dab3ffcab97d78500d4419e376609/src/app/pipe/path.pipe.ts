import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'path'
})
export class PathPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    if (args === 'name') {
      const a = value.split('/');
      const l = a.length;
      return a[l - 1];
    }
    return null;
  }

}
