<style src='../sass/_animate.scss' lang="scss"></style>

<style src="./share.scss" lang="scss"></style>
