# Aio UI

# Usage

see [doc](./src/introduce/doc.md)

# Develop

```bash
npm run dev     # local server to test
npm run build   # build minjs to dist/
```

# Doc

自动生成文档(建议目录`src/<组件名字>/<这里>`)，要求如下：

* `example.(ios | android)?.html`页面模拟终端展示
* `doc.md`页面文档展示
