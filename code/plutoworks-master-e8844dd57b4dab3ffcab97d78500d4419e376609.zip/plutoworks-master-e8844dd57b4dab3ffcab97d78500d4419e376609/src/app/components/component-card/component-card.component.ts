import {Component, Input, OnInit} from '@angular/core';
import {vPrompt, vPromptWithInput} from '../../utils/vex';
import {gitClone} from '../../utils/git';
import {ElectronService} from '../../providers/electron.service';
import {httpGet} from '../../utils/http';
import {Project} from '../../model/project';
import {ToastrService} from 'ngx-toastr';
import {HttpClient} from '@angular/common/http';
import {ProjectService} from '../../providers/project.service';
import {existsFile, existsFolder, FSEcopy, generatorFolderName} from '../../utils/fs';
import {COMPONENT_TEMP} from '../../variable';
import {remove} from '../../utils/rm';

@Component({
  selector: 'app-component-card',
  templateUrl: './component-card.component.html',
  styleUrls: ['./component-card.component.scss']
})
export class ComponentCardComponent implements OnInit {
  @Input() url: string;
  @Input() projectPath: string;
  @Input() componentPath: string;
  template: any;
  public loading = false;

  constructor(public http: HttpClient,
              public electronService: ElectronService,
              public toastr: ToastrService,
              public projectService: ProjectService,
  ) {
  }

  ngOnInit() {
    this.getTemplate();
  }

  getTemplate() {
    httpGet(this.url)
      .then(res => res.data)
      .then(data => this.template = data['component'])
      .catch(err => this.toastr.error(err.toString()));
  }

  onClick(c) {
    const rootTempPath = this.electronService.path.join(
      this.projectPath,
      COMPONENT_TEMP
    );
    const name = c.name;
    const spath = c.path;
    const gitUrl = c.source.git.url;
    const gitBranch = c.source.git.branch;
    const gitTempPath = this.electronService.path.join(
      rootTempPath,
      name
    );
    // const targetPath = this.electronService.path.join(
    //   this.projectPath,
    //   this.componentPath,
    //   name
    // );
    // const message = existsFolder(targetPath) ? `❗️ ${name} 已经存在，修改名字或覆盖添加：` : '组件名字：';

    // 可以调整一下顺序，先克隆，再判断是否存在, 使用generatorFolderName解决名字冲突。
    vPromptWithInput(
      {
        message: '组件名字：',
        value: name,
        placeholder: 'Input directory name',
        required: true
      },
      r => {
        if (r) {
          this.loading = true;
          // 克隆
          gitClone(gitUrl, gitTempPath, gitBranch, true).then(
            (result) => {
              // 拷贝
              const sourcePath = this.electronService.path.join(
                gitTempPath,
                spath
              );
              const newTargetPath = generatorFolderName(this.electronService.path.join(
                this.projectPath,
                this.componentPath,
                r
              ));
              const n = newTargetPath.split('/').pop();

              FSEcopy(sourcePath, newTargetPath).then(() => {
                // 删除临时文件夹
                remove(rootTempPath);
                this.loading = false;
                this.toastr.success(`组件 ${ n } 添加成功，手动引用并使用。`);
              }).catch(err => {
                this.loading = false;
                this.toastr.error(err);
              });
            },
            (err) => {
              this.loading = false;
              this.toastr.error(err);
            }
          );
        }
      }
    );
  }
}
