# picker

### TODO

* [] 3d 滚轮样式
* [] defaultValue & SetValue 可选列设置值
* [] value 支持 Obejct 格式

### 如何使用

ES Module

```js
Vue.use(AioUI);

const defaultData = {
  column1: [
    { name: "你是谁", value: 1 },
    { name: "你是谁", value: 2 },
    { name: "你是谁", value: 3 },
    { name: "偶数向下", value: "default" },
    { name: "我是谁", value: 5 },
    { name: "aio", value: "aio" },
    { name: "你是谁", value: 7 },
    { name: "你是谁", value: 8 }
  ],
  column2: [
    { name: "奇数中间", value: "default" },
    { name: "右边英文", value: "right" },
    { name: "你是谁", value: 3 },
    { name: "你是谁", value: 3 },
    { name: "aio", value: "aio" }
  ],
  column3: [
    { name: "你是谁", value: 1 },
    { name: "你是谁", value: 2 },
    { name: "你是谁", value: 3 },
    { name: "你是谁", value: 4 },
    { name: "奇数中间", value: "default" },
    { name: "你是谁", value: 6 },
    { name: "你是谁", value: 7 },
    { name: "你是谁", value: 8 },
    { name: "aio", value: "aio" }
  ]
};

const changeData = {
  column1: [
    { name: "A", value: "A" },
    { name: "B", value: "B" },
    { name: "C", value: "C" },
    { name: "D", value: "D" },
    { name: "E", value: "E" }
  ],
  column2: [
    { name: "a", value: "a" },
    { name: "b", value: "b" },
    { name: "c", value: "c" },
    { name: "d", value: "d" },
    { name: "e", value: "e" }
  ]
};

function consoleValue(value) {
  console.log(value);
}

function pickerChange(key, value, setData) {
  if (key == Object.keys(defaultData)[1] && value == "right") {
    setData(Object.keys(defaultData)[2], changeData.column2, "d");
  }
  if (key == Object.keys(defaultData)[2] && /^(a|b|c|d|e)$/.test(value)) {
    setData(
      Object.keys(defaultData)[0],
      changeData.column1,
      value.toLocaleUpperCase()
    );
  }
}

var app = new Vue({
  el: "#vue",
  data: {
    message: "Test Aio-Picker"
  },
  mounted() {
    let picker = new this.$AIOPicker({
      data: defaultData,
      cancel: consoleValue,
      submit: consoleValue,
      changed: pickerChange
    });

    picker.show();
  }
});
```

<script\>

```js
var picker = new Vue.AIOPicker({
  data: defaultData,
  defaultValue: ["aio", "aio", "aio"],
  cancel: consoleValue,
  submit: consoleValue,
  changed: pickerChange
});
picker.show();
```

### API

<details>
<summary>new Vue.AIOPicker(options)</summary>
_初始化一个swipe_  

| Parameters   | Types                  | Required | Default              | Description                                                                                                                                   |
| ------------ | ---------------------- | -------- | -------------------- | --------------------------------------------------------------------------------------------------------------------------------------------- |
| data         | Object<String：Array\> | Yes      |                      | 格式请参考上方 demo                                                                                                                           |
| defaultValue | Array<String\|Number\> | No       | 奇数中间，偶数/2 + 1 | 数组个数和 data 的 keys 保持一致，并且 value 值正确                                                                                           |
| cancel       | Function               | No       |                      | value<Array\> =\> void                                                                                                                        |
| submit       | Function               | No       |                      |  value<Array\> =\> void                                                                                                                       |
| changed      | Function               | No       |                      | (key, value, (key, newData, defaultValue) => void ) => void 此处 key 表示 data 的 key，第三个参数 setData，可重新设置 data，具体请看上边 demo |

</details>

<details>
<summary>Instances.show()</summary>
_显示_
</details>

<details>
<summary>Instances.hide()</summary>
_隐藏_
</details>

<details>
<summary>Instances.setValue(value)</summary>
_设置值_

| Parameters | Types                  | Required | Description                                         |
| ---------- | ---------------------- | -------- | --------------------------------------------------- |
| value      | Array<String\|Number\> | Yes      | 数组个数和 data 的 keys 保持一致，并且 value 值正确 |

</details>

<details>
<summary>Instances.getValue()</summary>
_获取值_

| Return | Types                  | Description           |
| ------ | ---------------------- | --------------------- |
| value  | Array<String\|Number\> | picker 选择器的返回值 |

</details>

### 其他

项目 & 文档问题和建议请发送邮件 pluto.list@jiedaibao.com
