import { Component, OnInit } from '@angular/core';
import { ElectronService } from '../../providers/electron.service';
import { Project } from '../../model/project';
import { ProjectService } from '../../providers/project.service';
import { vPromptWithCheckbox } from '../../utils/vex';
import { remove } from '../../utils/rm';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {
  projects: Project[];

  constructor(public electronService: ElectronService,
              public projectService: ProjectService,
              public toastr: ToastrService,
              public router: Router) {
    this.getAll();
  }

  getAll(id?: string) {
    this.projects = this.projectService.getAll();

    if (id) {
      this.router.navigate(['/home/detail', id]);
    }
  }

  selectProject() {
    const f = this.electronService.remote.dialog.showOpenDialog({properties: ['openDirectory']});
    if (f) {
      const p = new Project(f[0]);
      this.projectService.insertOne(
        p,
        bool => bool ? this.getAll(p.id) : this.toastr.warning(`${p.name} 已经存在`));
    }
  }

  openFile(path: string) {
    this.electronService.remote.shell.openItem(path);
  }

  deleteById(project: Project) {
    vPromptWithCheckbox(`确认删除${project.name}?`, '同时删除项目文件(谨慎选择)', v => {
      if (v) {
        if (v.checked) {
          // console.log('删除源文件');
          remove(project.path);
        } else {
          // console.log('删除，但是不删除源文件');
        }
        this.projectService.deleteById(project.id);
        this.getAll();
      } else {
        // console.log('不删除');
      }
    });
  }
}
