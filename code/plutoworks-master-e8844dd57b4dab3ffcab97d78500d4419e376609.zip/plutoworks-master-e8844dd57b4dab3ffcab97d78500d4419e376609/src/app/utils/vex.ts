export function vPrompt(message: string, placeholder: string = '', cb: (v) => void): void {
  vex.dialog.prompt({
    message: message,
    placeholder: placeholder,
    className: 'vex-theme-default',
    callback: v => cb(v)
  });
}

export function vAlert(message: string): void {
  vex.dialog.alert(
    {
      message: message,
      className: 'vex-theme-default'
    }
  );
}

export function vPromptWithCheckbox(title: string, message: string, cb: (v) => void): void {
  vex.dialog.open(
    {
      message: title,
      className: 'vex-theme-default',
      input: [
        `<input name="checked" type="checkbox" /> ${message}`
      ].join(''),
      callback: v => cb(v)
    }
  );
}

export function vConfirm(ops): void {
  vex.dialog.confirm(
    Object.assign(
      {
        className: 'vex-theme-default'
      },
      ops));
}

export function vPromptWithInput(ops, cb: (v) => void): void {
  const type = `type="${ops.type || 'text'}"`;
  const value = ops.value ? `value="${ops.value}"` : '';
  const required = ops.required ? `required` : '';
  const placeholder = ops.placeholder ? `placeholder="${ops.placeholder}"` : '';
  const input = `<input name="vex" ${type} ${placeholder} ${required} ${value} class="vex-dialog-prompt-input">`;

  vex.dialog.prompt({
    message: ops.message,
    className: 'vex-theme-default',
    input: input,
    callback: v => cb(v)
  });
}
