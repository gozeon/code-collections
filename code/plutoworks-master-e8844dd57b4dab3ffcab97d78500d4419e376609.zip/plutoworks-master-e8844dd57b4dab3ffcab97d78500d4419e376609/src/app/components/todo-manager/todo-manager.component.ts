import {AfterContentChecked, Component, DoCheck, Input, OnChanges, SimpleChanges} from '@angular/core';
import {getTodosByLeasot} from '../../utils/leasot';
import {from, of} from 'rxjs';
import {catchError} from 'rxjs/operators';
import {ToastrService} from 'ngx-toastr';

@Component({
  selector: 'app-todo-manager',
  templateUrl: './todo-manager.component.html',
  styleUrls: ['./todo-manager.component.scss']
})
export class TodoManagerComponent implements OnChanges, DoCheck {
  @Input() path: string;
  todos: any;
  todoMap = new Map();

  constructor(public toastr: ToastrService) {
  }

  async ngOnChanges(changes: SimpleChanges) {
    const p = changes['path'].currentValue;

    await getTodosByLeasot(p).then(todos => {
      this.todoMap.set(p, todos);
    }).catch(err => {
      this.toastr.error(err.toString());
    });
  }

  ngDoCheck() {
    this.todos = this.todoMap.get(this.path) || {};
  }

  getTodo(path) {

    // from(getTodosByLeasot(path)).pipe(
    //   catchError(err => {
    //     console.log(err);
    //     return of([]);
    //   })
    // );

    getTodosByLeasot(this.path).then(todos => {

      this.todos = todos;
    }).catch(err => {
      console.log('err', err);
    });
  }
}
