import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ScriptsManagerComponent } from './scripts-manager.component';

describe('ScriptsManagerComponent', () => {
  let component: ScriptsManagerComponent;
  let fixture: ComponentFixture<ScriptsManagerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ScriptsManagerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScriptsManagerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
