// show(title,content,[btn],[btn2],[success],[this._iosCannel]）
// title:标题文字内容(必选)
// content:alert文字内容(必选)
// [btn]:确认按钮文字(可选，默认为‘知道了’)
// [btn2]:确认按钮文字(可选，默认为‘知道了’)
// [success]:确认按钮回掉函数(可选，默认为隐藏dialog弹框)
// [cannel]:取消按钮回掉函数(可选，默认为隐藏dialog弹框)

export class Dialog {
  constructor() {
    this._iosDialogBox = document.createElement("div");
    this._iosMask = document.createElement("div");
    this._iosDialogTitle = document.createElement("strong");
    this._iosDialogBd = document.createElement("div");
    this._iosCannel = document.createElement("a");
    this._iosConfirm = document.createElement("a");
    this._singleton = 0;
    this._init();
  }

  _init() {
    this._iosDialogBox.style.display = "none";
    this._iosDialogBox.id = this.id;

    this._iosMask.classList.add("aio-mask");

    let iosDialog = document.createElement("div");
    iosDialog.classList.add("ios-dialog");

    this._iosDialogTitle.classList.add("ios-dialog-title");

    let iosDialogHd = document.createElement("div");
    iosDialogHd.classList.add("ios-dialog-hd");

    this._iosDialogBd.classList.add("ios-dialog-bd");

    let iosDialogFt = document.createElement("div");
    iosDialogFt.classList.add("ios-dialog-ft");

    this._iosConfirm.href = "javascript:;";
    this._iosConfirm.classList.add("ios-dialog-btn", "ios-dialog-btn-primary");

    this._iosCannel.href = "javascript:;";
    this._iosCannel.classList.add("ios-dialog-btn", "ios-dialog-btn-default");

    iosDialogFt.append(this._iosCannel, this._iosConfirm);

    iosDialogHd.appendChild(this._iosDialogTitle);

    iosDialog.append(iosDialogHd, this._iosDialogBd, iosDialogFt);

    this._iosDialogBox.append(this._iosMask, iosDialog);

    document.body.appendChild(this._iosDialogBox);
  }

  show(title, content, btn = "知道了", btn2 = "取消", success, cannel) {
    this._iosDialogTitle.innerText = title;
    this._iosDialogBd.innerText = content;
    this._iosCannel.innerText = btn2;
    this._iosConfirm.innerText = btn;

    if (this._iosDialogBox.style.display != "none") {
      return;
    }
    this._iosDialogBox.style.display = "block";

    this._iosDialogBox.classList.remove("aio-animate-fade-out");
    this._iosDialogBox.classList.add("aio-animate-fade-in");

    if (this._singleton == 0) {
      this._singleton = 1;

      if (typeof success == "function") {
        this._iosConfirm.addEventListener("click", success);
        this._iosConfirm.addEventListener("click", () => this.hide());
      } else this._iosConfirm.addEventListener("click", () => this.hide());

      if (typeof this._iosCannel == "function") {
        this._iosCannel.addEventListener("click", cannel);
        this._iosCannel.addEventListener("click", () => this.hide());
      } else this._iosCannel.addEventListener("click", () => this.hide());
    }
  }

  hide() {
    this._iosDialogBox.classList.remove("aio-animate-fade-in");
    this._iosDialogBox.classList.add("aio-animate-fade-out");
    setTimeout(() => (this._iosDialogBox.style.display = "none"), 300);
  }
}
