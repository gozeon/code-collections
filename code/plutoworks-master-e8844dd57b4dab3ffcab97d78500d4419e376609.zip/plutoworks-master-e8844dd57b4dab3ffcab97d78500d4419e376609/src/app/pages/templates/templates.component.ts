import { Component, OnInit } from '@angular/core';
import { PlanetService } from '../../providers/planet.service';
import { Planet } from '../../model/planet';

@Component({
  selector: 'app-templates',
  templateUrl: './templates.component.html',
  styleUrls: ['./templates.component.scss']
})
export class TemplatesComponent {
  planets: Planet[];

  constructor(public planetService: PlanetService) {
    this.initData();
  }

  initData() {
    this.planets = this.planetService.getAll();
  }

}

