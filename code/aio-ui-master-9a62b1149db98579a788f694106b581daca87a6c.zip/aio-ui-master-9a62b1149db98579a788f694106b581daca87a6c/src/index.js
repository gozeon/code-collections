import testComponent from "./helloWorld/helloworld.vue";
import { HelloWorld } from "./helloWorld/helloworld";

import swipeComponent from "./swipe/swipe.vue";
import { Swipe } from "./swipe/swipe";

import pickerComponent from "./picker/picker.vue";
import { Picker } from "./picker/picker";

import toastIconComponent from "./toast/icon/toastIcon.vue";
import { ToastIcon } from "./toast/icon/toastIcon";

import toastTextComponent from "./toast/text/toastText.vue";
import { ToastText } from "./toast/text/toastText";

//**liangyuqi task**
import actionSheetComponent from "./actionsheet/actionSheet.vue";
import { ActionSheet } from "./actionsheet/actionSheet";

// import androidActionSheetComponent from "./actionsheet/android/androidActionSheet.vue";
// import { AndroidActionSheet } from "./actionsheet/android/androidActionSheet";

// import iosActionSheetComponent from "./actionsheet/ios/iosActionSheet.vue";
// import { IosActionSheet } from "./actionsheet/ios/iosActionSheet";

import dialogComponent from "./dialog/dialog/iosDialog.vue";
import { Dialog } from "./dialog/dialog/iosDialog";

import alertComponent from "./dialog/alert/iosAlert.vue";
import { Alert } from "./dialog/alert/iosAlert";

import shareComponent from "./share/share.vue";
import { Share } from "./share/share";

const AioUI = {
  install: (Vue, options) => {
    if (!options) {
      options = {};
    }

    let h = new HelloWorld("Test: AIOHelloWorld");
    Vue.component("AIOHelloWorld", testComponent);
    Vue.AIOHelloWorld = Vue.prototype.$AIOHelloWorld = h;

    Vue.component("AIOSwipe", swipeComponent);
    Vue.AIOSwipe = Vue.prototype.$AIOSwipe = Swipe;

    Vue.component("AIOPicker", pickerComponent);
    Vue.AIOPicker = Vue.prototype.$AIOPicker = Picker;

    Vue.component("AIOToastIcon", toastIconComponent);
    Vue.AIOToastIcon = Vue.prototype.$AIOToastIcon = ToastIcon;

    Vue.component("AIOToastText", toastTextComponent);
    Vue.AIOToastText = Vue.prototype.$AIOToastText = ToastText;

    Vue.component("AIOActionSheet", actionSheetComponent);
    Vue.AIOActionSheet = Vue.prototype.$AIOActionSheet = ActionSheet;

    // Vue.component("AIOAndroidActionSheet", androidActionSheetComponent);
    // Vue.AIOAndroidActionSheet = Vue.prototype.$AIOAndroidActionSheet = AndroidActionSheet;

    // Vue.component("AIOIosActionSheet", iosActionSheetComponent);
    // Vue.AIOIosActionSheet = Vue.prototype.$AIOIosActionSheet = IosActionSheet;

    Vue.component("AIODialog", dialogComponent);
    Vue.AIODialog = Vue.prototype.$AIODialog = Dialog;

    Vue.component("AIOAlert", alertComponent);
    Vue.AIOAlert = Vue.prototype.$AIOAlert = Alert;

    Vue.component("AIOShare", shareComponent);
    Vue.AIOShare = Vue.prototype.$AIOShare = Share;
  }
};

// register plugin if it is used via cdn or directly as a script tag
if (typeof window !== "undefined" && window.Vue) {
  window.AioUI = AioUI;
}

export default AioUI;
