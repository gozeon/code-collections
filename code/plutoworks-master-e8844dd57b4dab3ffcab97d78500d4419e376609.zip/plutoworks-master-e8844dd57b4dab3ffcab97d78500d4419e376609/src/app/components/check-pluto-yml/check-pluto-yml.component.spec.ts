import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckPlutoYmlComponent } from './check-pluto-yml.component';

describe('CheckPlutoYmlComponent', () => {
  let component: CheckPlutoYmlComponent;
  let fixture: ComponentFixture<CheckPlutoYmlComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckPlutoYmlComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckPlutoYmlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
