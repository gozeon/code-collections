<style src="./toastIcon.scss" lang="scss"> </style>
<style src='../../sass/_animate.scss' lang="scss"></style>
<style src='../../sass/_mask.scss' lang="scss"></style>