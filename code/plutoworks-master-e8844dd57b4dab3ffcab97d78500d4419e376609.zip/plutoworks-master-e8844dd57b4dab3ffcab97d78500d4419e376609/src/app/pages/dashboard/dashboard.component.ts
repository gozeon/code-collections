import {ChangeDetectorRef, Component, OnInit} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {ProjectService} from '../../providers/project.service';
import {Project} from '../../model/project';
import {readPackage, watchFiles} from '../../utils/fs';
import {ElectronService} from '../../providers/electron.service';
import {ToastrService} from 'ngx-toastr';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  project: Project;
  pkgData: any;

  constructor(
    public route: ActivatedRoute,
    public projectService: ProjectService,
    public toastr: ToastrService,
    public electronService: ElectronService,
    public changeDetectorRef: ChangeDetectorRef
  ) {
    this.route.params.subscribe(params => {
        this.project = this.projectService.findById(params['id']);
        this.getPkgContent(this.project.path);
      }
    );
  }

  ngOnInit() {
    const pkgPath = this.electronService.path.join(this.project.path, 'package.json');

    watchFiles(pkgPath, (curr, prev) => {
      this.getPkgContent(this.project.path);
    });
  }

  getPkgContent(path: string) {
    readPackage(path)
      .then(data => {
        this.pkgData = data;
        this.changeDetectorRef.detectChanges();
      })
      .catch(error => {
        this.toastr.error(error);
        this.pkgData = null;
      });

  }

}
