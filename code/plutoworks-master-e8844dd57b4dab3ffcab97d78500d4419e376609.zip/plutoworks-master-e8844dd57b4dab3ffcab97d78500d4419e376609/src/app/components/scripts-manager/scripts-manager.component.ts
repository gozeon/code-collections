import {ChangeDetectorRef, Component, Input, OnChanges, OnInit, SimpleChanges, DoCheck, ChangeDetectionStrategy} from '@angular/core';
import {readPackage, watchFiles} from '../../utils/fs';
import {ToastrService} from 'ngx-toastr';
import {ElectronService} from '../../providers/electron.service';
import {from, of} from 'rxjs';
import {catchError} from 'rxjs/operators';

@Component({
  selector: 'app-scripts-manager',
  templateUrl: './scripts-manager.component.html',
  styleUrls: ['./scripts-manager.component.scss'],
})
export class ScriptsManagerComponent implements OnChanges, OnInit {
  @Input() path: string;
  pkgData: any;

  constructor(public toastr: ToastrService,
              public electronService: ElectronService,
              public changeDetectorRef: ChangeDetectorRef) {
  }

  ngOnInit() {
    const pkgPath = this.electronService.path.join(this.path, 'package.json');

    watchFiles(pkgPath, (curr, prev) => {
      this.getPkgContent(this.path);
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    const p = changes['path'].currentValue;

    this.getPkgContent(p);
  }

  getPkgContent(path: string) {

    readPackage(path)
      .then(data => {
        this.pkgData = data;
        this.changeDetectorRef.detectChanges();
      })
      .catch(error => {
        this.toastr.error(error);
        this.pkgData = null;
      });

  }

  edit() {
  }
}
