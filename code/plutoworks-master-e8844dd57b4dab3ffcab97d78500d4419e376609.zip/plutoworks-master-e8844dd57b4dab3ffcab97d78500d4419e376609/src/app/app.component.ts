import {Component} from '@angular/core';
import {ElectronService} from './providers/electron.service';
import {TranslateService} from '@ngx-translate/core';
import {AppConfig} from '../environments/environment';
import {Project} from './model/project';
import {Planet} from './model/planet';
import {PlanetService} from './providers/planet.service';
import {vConfirm} from './utils/vex';
import {d} from './utils/download';
import {compareVersion, createUrl, getRemoteConfig} from './utils/update';
import {ToastrService} from 'ngx-toastr';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  isShowNav = false;

  constructor(public electronService: ElectronService,
              private translate: TranslateService,
              public planetService: PlanetService,
              public toastr: ToastrService) {

    translate.setDefaultLang('en');
    console.log('AppConfig', AppConfig);
    getRemoteConfig()
      .then(data => {
        const name = data['name'];
        const newVersion = data['version'];
        const r = compareVersion(electronService.remote.app.getVersion(), newVersion);
        if (r === -1) {
          vConfirm({
            message: `检查到新版本v${newVersion}，是否要更新？`,
            callback: (v) => {
              if (v) {
                d({url: createUrl(name, newVersion)})
                  .then(file => {
                    if (confirm(`v${newVersion}下载完成，是否现在安装？`)) {
                      electronService.remote.shell.openItem(file);
                    }
                  })
                  .catch(err => this.toastr.error(err.toString()));
              }
            }
          });
        }
      })
      .catch(err => {
        this.toastr.error(err.toString());
      });


    if (electronService.isElectron()) {
      console.log('version', electronService.remote.app.getVersion());
      // if (confirm(1)) {
      //   window.open('http://test.office.jiedaibao.com/plutoworks/plutoworks-0.0.2.dmg');
      // }
      console.log('Electron ipcRenderer', electronService.ipcRenderer);
      console.log('NodeJS childProcess', electronService.childProcess);
    } else {
      console.log('Mode web');
    }

    const aas = new Project('/Users/goze/Documents/github/angular-electron');
    console.log(new Planet('hah', 'as'));
    console.log(planetService.getAll());
    this.planetService.insertOne(new Planet('angular', 'http://47.104.30.27/angular-planet.json'));
  }

  showNav() {
    this.isShowNav = !this.isShowNav;
  }
}
