const yaml = window.require('js-yaml');
const {lstatSync, readdirSync, existsSync, readFileSync, watchFile, watch} = window.require('fs');
const {join} = window.require('path');
const readPkg = window.require('read-pkg');
const fse = window.require('fs-extra');

export function existsFile(projectPath: string, fileName: string): Boolean {
  const p = join(projectPath, fileName);
  return existsSync(p);
}

export function existsFolder(projectPath: string): Boolean {
  return existsSync(projectPath);
}

export function readYaml(yamlPath: string) {
  return yaml.safeLoad(readFileSync(yamlPath, 'utf8'));
}

const isDirectory = source => lstatSync(source).isDirectory();
export const getDirectories = source => {
  if (!existsSync(source)) {
    return [];
  }

  return readdirSync(source).map(name => join(source, name)).filter(isDirectory);
};

export function watchFiles(file, cb) {
  watchFile(file, (curr, prev) => {
    cb(curr, prev);
  });
}

export async function readPackage(path: string) {
  return await readPkg({cwd: path});
}

export function FSEcopy(source, target) {
  return fse.copy(source, target);
}

export function generatorFolderName(folderPath: string) {
  const tmp = folderPath;
  let index = 0;

  while (existsFolder(folderPath)) {
    folderPath = tmp + ` (${++index})`;
  }

  return folderPath;
}
