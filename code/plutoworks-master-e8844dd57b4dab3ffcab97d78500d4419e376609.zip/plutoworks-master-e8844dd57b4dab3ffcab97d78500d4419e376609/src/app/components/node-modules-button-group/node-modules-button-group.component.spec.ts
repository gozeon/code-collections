import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NodeModulesButtonGroupComponent } from './node-modules-button-group.component';

describe('NodeModulesButtonGroupComponent', () => {
  let component: NodeModulesButtonGroupComponent;
  let fixture: ComponentFixture<NodeModulesButtonGroupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NodeModulesButtonGroupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NodeModulesButtonGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
