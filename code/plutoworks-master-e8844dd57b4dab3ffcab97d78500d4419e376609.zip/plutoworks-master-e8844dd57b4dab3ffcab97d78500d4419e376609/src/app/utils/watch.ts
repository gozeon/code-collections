const chokidar = window.require('chokidar');

export function folderWatch(path: string, callback: any) {
  chokidar.watch(path, {ignored: /(^|[\/\\])\../}).on('all', (event, p) => {
    callback(event, p);
  });
}
