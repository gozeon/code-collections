# Aio Ui

此文档是 `aio` 的 `ui` 库，框架选择 `vue`，打包工具选择 `webpack`。

### 任务列表

组件

* [x] checked Picker
* [x] checked Swipe
* [x] Toast
* [x] Share
* [x] Dialog
* [x] Actionsheet

项目

* [x] webpack build umd & cjs2
* [ ] js 事件别名

文档

* [x] 自动生成文档
* [ ] dev server & hmr(fs 写成 plugin)
* [ ] 页面样式
* [ ] 模拟器样式 & 模拟器事件(touch)

### 组件定义

> 方法组件、智能组件、木偶组件

* 方法组件：类似于 `alert`、`console.*` 方法的组件，没有标签，采用 `js.<方法>` 的使用方式.
* 智能组件：包含交互逻辑的组件。
* 木偶组件：没有交互，只负责显示。

### 引入

方法一：

```bash
# echo 'registry=http://100.73.16.43:4873/' >> .npmrc
npm install aio-ui --save-dev
```

then

```js
import AioUI from 'aio-ui';
Vue.use(AioUI);
...
```

方法二：

```html
<script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
<script type="text/javascript" src="<path>/node_modules/aio-ui/dist/aio-ui.min.umd.js"></script>
<script>
	Vue.use(AioUI);
	...
</script>
```

组件详细使用方法请点击对应的左侧菜单。

### 贡献代码

* [百度脑图](http://naotu.baidu.com/file/d2452774b39bd6c97c1f3a64c557b90d?token=01b576a6c19bdbe0)
* [Gitlab](http://jdb-dev.com/plutolab/aio-ui)
* [开发文档](http://jdb-dev.com/plutolab/aio-ui/blob/master/README.md)

更多请查看 `Hello World`

### 其他

项目 & 文档问题和建议请发送邮件 pluto.list@jiedaibao.com
