// show([msg],[autoclose],[delay])
// [msg]:文字（选填，默认为‘成功’），
// [autoclose]:是否自动取消（选填,默认自动取消），
// [delay]:取消延时ms（选填，默认2000ms）

// hide()

export class ToastText {
  constructor() {
    this._toastText = document.createElement("div");
    this._mask = document.createElement("div");
    this.init();
  }

  init() {
    this._toastText.style.display = "none";
    this._toastText.classList.add("toast-text");
    this._mask.classList.add("aio-mask-transparent");

    let toastTextBg = document.createElement("div");
    toastTextBg.classList.add("toast-text-bg");

    this._toastTextTxt = document.createElement("p");
    this._toastTextTxt.classList.add("toast-text-txt");

    toastTextBg.appendChild(this._toastTextTxt);
    this._toastText.append(this._mask, toastTextBg);
    document.body.appendChild(this._toastText);
  }

  show(msg = "成功", autoclose = true, delay = 2000) {
    this._toastTextTxt.innerText = msg;

    if (this._toastText.style.display != "none") {
      return;
    }
    this._toastText.style.display = "block";

    this._toastText.classList.remove("aio-animate-fade-out");
    this._toastText.classList.add("aio-animate-fade-in");

    if (autoclose) this._toastTextTimer = setTimeout(() => this.hide(), delay);
  }

  hide() {
    clearTimeout(this._toastTextTimer);
    this._toastText.classList.remove("aio-animate-fade-in");
    this._toastText.classList.add("aio-animate-fade-out");
    setTimeout(() => (this._toastText.style.display = "none"), 300);
  }
}
