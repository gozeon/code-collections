import tpl from "./helloworld.html";
import { TemplateEngine } from "../util";

export class HelloWorld {
  constructor(msg) {
    this.id = "hello";

    this.init(msg);
  }

  init(msg) {
    const data = {
      id: this.id,
      message: msg,
      show: true,
      list: ["apple", "banana", "orange"]
    };

    document.body.insertAdjacentHTML("beforeend", TemplateEngine(tpl, data));
    document.querySelector(`#${this.id}`).style.display = "none";
  }

  show() {
    if (document.getElementById(this.id)) {
      document.getElementById(this.id).style.display = "block";
      return;
    }
  }

  hide() {
    document.getElementById(this.id).style.display = "none";
  }
}
