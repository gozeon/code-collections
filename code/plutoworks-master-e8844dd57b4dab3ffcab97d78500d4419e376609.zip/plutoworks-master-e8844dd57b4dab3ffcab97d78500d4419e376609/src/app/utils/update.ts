import {httpGet} from './http';
import {CHECK_VERSION_URL, DOWNLOAD_URL} from '../variable';

const yaml = require('js-yaml');

const compareVersions = require('compare-versions');

/*
 compareVersions('10.1.8', '10.0.4'); //  1
 compareVersions('10.0.1', '10.0.1'); //  0
 compareVersions('10.1.1', '10.2.2'); // -1
 */
export function compareVersion(oldVersion, newVersion) {
  return compareVersions(oldVersion, newVersion);
}

export function getRemoteConfig(): any {
  // TODO: 暂时使用下面地址
  return new Promise((resolve, reject) => {
    httpGet(CHECK_VERSION_URL)
      // .then(res => yaml.load(res.data))
      .then(res => res.data)
      .then(data => resolve(data))
      .catch(err => reject(err));
  });
}

export function createUrl(name, version) {
  // TODO: 暂时使用下面地址
  return `${DOWNLOAD_URL}/${name}-${version}.dmg`;
}
