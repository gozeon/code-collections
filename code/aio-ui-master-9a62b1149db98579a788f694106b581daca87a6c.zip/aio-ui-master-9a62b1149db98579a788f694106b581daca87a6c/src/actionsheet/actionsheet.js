/**
 * IosActionSheet
 *  @param options
 * {
 *    title:{string},
 *    menu:{array},
 *    cancel:{string}
 * }
 */

export class ActionSheet {
  constructor(options) {
    if (options.type == "ios") {
      this._iosActionsheet = document.createElement("div");
      this._iosMask = document.createElement("div");
      this._iosInit(options);
      this.show = this._iosShow;
      this.hide = this._iosHide;
    } else if (options.type == "android") {
      this._androidActionsheet = document.createElement("div");
      this._androidMask = document.createElement("div");
      this._androidActionSheetBox = document.createElement("div");
      this._androidInit(options);
      this.show = this._androidShow;
      this.hide = this._androidHide;
    }
  }

  _iosInit(options) {
    this._iosMask.classList.add("aio-mask");
    this._iosMask.style.display = "none";

    this._iosActionsheet.classList.add("ios-actionsheet");

    let iosActionsheetTitle = document.createElement("div");
    iosActionsheetTitle.classList.add("ios-actionsheet-title");

    let iosActionsheetTitleText = document.createElement("p");
    iosActionsheetTitleText.classList.add("ios-actionsheet-title-text");

    let iosActionsheetMenu = document.createElement("div");
    iosActionsheetMenu.classList.add("ios-actionsheet-menu");

    let iosActionsheetAction = document.createElement("div");
    iosActionsheetAction.classList.add("ios-actionsheet-action");

    let iosActionsheetActionCell = document.createElement("div");
    iosActionsheetActionCell.classList.add(
      "ios-actionsheet-action-cell",
      "ios-actionsheet-cell"
    );

    iosActionsheetTitle.appendChild(iosActionsheetTitleText);

    iosActionsheetAction.appendChild(iosActionsheetActionCell);

    this._iosActionsheet.append(
      iosActionsheetTitle,
      iosActionsheetMenu,
      iosActionsheetAction
    );

    document.body.append(this._iosMask, this._iosActionsheet);
    document.getElementsByClassName("ios-actionsheet-title-text")[0].innerText =
      options.title;

    for (let i = 0; i < options.menu.length; i++) {
      let iosActionsheetCell = document.createElement("div");

      iosActionsheetCell.classList.add("ios-actionsheet-cell");
      iosActionsheetCell.innerText = options.menu[i];

      document
        .getElementsByClassName("ios-actionsheet-menu")[0]
        .appendChild(iosActionsheetCell);
    }

    document.getElementsByClassName(
      "ios-actionsheet-action-cell"
    )[0].innerText =
      options.cannel || "取消";
  }

  _iosShow() {
    if (this._iosMask.style.display != "none") {
      return;
    }
    this._iosMask.style.display = "block";

    this._iosMask.classList.remove("aio-animate-fade-out");
    this._iosMask.classList.add("aio-animate-fade-in");

    this._iosActionsheet.classList.add("ios-actionsheet-toggle");

    this._iosMask.addEventListener("click", () => {
      this.hide();
    });

    document
      .getElementsByClassName("ios-actionsheet-action-cell")[0]
      .addEventListener("click", () => {
        this.hide();
      });
  }

  _iosHide() {
    this._iosActionsheet.classList.remove("ios-actionsheet-toggle");
    this._iosMask.classList.remove("aio-animate-fade-in");
    this._iosMask.classList.add("aio-animate-fade-out");
    setTimeout(() => (this._iosMask.style.display = "none"), 300);
    document.getElementsByClassName("ios-actionsheet-menu")[0].innerHTML = "";
  }
  _androidInit(options) {
    this._androidActionSheetBox.style.display = "none";
    this._androidActionsheet.classList.add("android-actionsheet");

    this._androidMask.classList.add("aio-mask");

    let actionsheetMenu = document.createElement("div");
    actionsheetMenu.classList.add("android-actionsheet-menu");

    this._androidActionsheet.appendChild(actionsheetMenu);

    this._androidActionSheetBox.append(
      this._androidMask,
      this._androidActionsheet
    );

    document.body.append(this._androidActionSheetBox);
    if (this._androidActionSheetBox.style.display != "none") {
      return;
    }

    for (let i = 0; i < options.menu.length; i++) {
      let androidActionsheetCell = document.createElement("div");

      androidActionsheetCell.classList.add("android-actionsheet-cell");
      androidActionsheetCell.innerText = options.menu[i];

      document
        .getElementsByClassName("android-actionsheet-menu")[0]
        .appendChild(androidActionsheetCell);
    }
  }

  _androidShow() {
    this._androidActionSheetBox.style.display = "block";
    this._androidActionSheetBox.classList.remove("aio-animate-fade-out");
    this._androidActionSheetBox.classList.add("aio-animate-fade-in");

    this._androidMask.addEventListener("click", () => this.hide());
  }

  _androidHide() {
    this._androidActionSheetBox.classList.remove("aio-animate-fade-in");
    this._androidActionSheetBox.classList.add("aio-animate-fade-out");

    setTimeout(() => (this._androidActionSheetBox.style.display = "none"), 300);

    document.getElementsByClassName("android-actionsheet-menu")[0].innerHTML =
      "";
  }
}
