/**
 * AndroidActionSheet
 *  @param options
 * {
 *    menu:{array} [any, any, any, ...]
 * }
 */

export class AndroidActionSheet {
  constructor(options) {
    this._androidActionsheet = document.createElement("div");
    this._androidMask = document.createElement("div");
    this._androidActionSheetBox = document.createElement("div");
    this._init(options);
  }

  _init(options) {
    this._androidActionSheetBox.style.display = "none";
    this._androidActionsheet.classList.add("android-actionsheet");

    this._androidMask.classList.add("aio-mask");

    let actionsheetMenu = document.createElement("div");
    actionsheetMenu.classList.add("android-actionsheet-menu");

    this._androidActionsheet.appendChild(actionsheetMenu);

    this._androidActionSheetBox.append(
      this._androidMask,
      this._androidActionsheet
    );

    document.body.append(this._androidActionSheetBox);
    if (this._androidActionSheetBox.style.display != "none") {
      return;
    }

    for (let i = 0; i < options.menu.length; i++) {
      let androidActionsheetCell = document.createElement("div");

      androidActionsheetCell.classList.add("android-actionsheet-cell");
      androidActionsheetCell.innerText = options.menu[i];

      document
        .getElementsByClassName("android-actionsheet-menu")[0]
        .appendChild(androidActionsheetCell);
    }
  }

  show() {
    this._androidActionSheetBox.style.display = "block";
    this._androidActionSheetBox.classList.remove("aio-animate-fade-out");
    this._androidActionSheetBox.classList.add("aio-animate-fade-in");

    this._androidMask.addEventListener("click", () => this.hide());
  }

  hide() {
    this._androidActionSheetBox.classList.remove("aio-animate-fade-in");
    this._androidActionSheetBox.classList.add("aio-animate-fade-out");

    setTimeout(() => (this._androidActionSheetBox.style.display = "none"), 300);

    document.getElementsByClassName("android-actionsheet-menu")[0].innerHTML =
      "";
  }
}
