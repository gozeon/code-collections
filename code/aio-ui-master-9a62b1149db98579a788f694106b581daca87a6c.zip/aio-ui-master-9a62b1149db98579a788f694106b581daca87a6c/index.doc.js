import { TemplateEngine } from "./src/util";

showdown.extension("codehighlight", function() {
  function htmlunencode(text) {
    return text
      .replace(/&amp;/g, "&")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">");
  }
  return [
    {
      type: "output",
      filter: function(text, converter, options) {
        // use new shodown's regexp engine to conditionally parse codeblocks
        var left = "<pre><code\\b[^>]*>",
          right = "</code></pre>",
          flags = "g",
          replacement = function(wholeMatch, match, left, right) {
            // unescape match to prevent double escaping
            match = htmlunencode(match);
            let lang = (left.match(/class=\"([^ \"]+)/) || [])[1];

            /**
             * @link https://github.com/nodeca/ndoc/commit/ac7435bb279dc59707d02ab56c15ecfe3b41d3c3
             */
            if (lang && hljs.getLanguage(lang)) {
              return left + hljs.highlight(lang, match).value + right;
            } else {
              return left + hljs.highlightAuto(match).value + right;
            }
          };
        return showdown.helper.replaceRecursiveRegExp(
          text,
          replacement,
          left,
          right,
          flags
        );
      }
    }
  ];
});

const converter = new showdown.Converter({
  tasklists: true,
  tables: true,
  simplifiedAutoLink: true,
  extensions: ["codehighlight"]
});

const cursorCss =
  "html, body {cursor: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABI" +
  "AAAATCAMAAACqTK3AAAAAnFBMVEVKS0sAAAD6+vr39/fj4+OsrKxQUVHk5OTY2NjV1dVgYWHm5u" +
  "be3t7c3NzV1dXT09PPz8/q6ur19fXNzc2/v7/v7+/u7u6QkJB1dnbt7e1SU1Pd3d3b29vW1tbU1" +
  "NTT09Ps7Ozl5eXe39/e3t709PS7u7u5ublmZ2fp6enn5+fj4+Ph4eHg4ODc3Nzc3NzZ2dnZ2dnW" +
  "1tbU1NTT09Pxrtv7AAAANHRSTlPmAP78+fHnyPf26NGiizAcBfr49fPu7e3q6Oedh08oDPr5+Pj" +
  "38vLp3NfBuLGUkXRrSzgYlzzxjwAAAKFJREFUGNNl0NUOwzAMQFE7sDLzSmPm/f+/LY2atVXv45" +
  "FlyQac1ZPnaCfLdgdqr4TF/KATq+nJS1gOXWZE35L8wlhAHw+bjuxAiCqyOgozGDKJC1hTGKeXg" +
  "M52QnsN0DYmxM9iik0oFlMuWY6JVYCY8JHk5CvoSc2/LNY3edAlOCox0laSr1Eu92WrwlPPeaWE" +
  "6Ru6u/soSfapyketXjjrB1sXCDrwyo6RAAAAAElFTkSuQmCC') 8 8, auto!important}";

const navTmpl = `
<ul>
  <% for(let i = 0; i < this.list.length; i++) { %>

    <li>
      <a href="javascript:void(0)" data-src="<% this.list[i].src %>">
      <% this.list[i].label %></a>
    </li>
  <% } %>
</ul>
`;

const container = document.querySelector(".container");
const list = container.querySelector(".list");
const docElement = container.querySelector(".doc");

list.insertAdjacentHTML(
  "beforeend",
  TemplateEngine(navTmpl, { list: toObjectArr(resort(HTML_LIST)) })
);

const aGroup = list.querySelectorAll("ul li a");
const iFrame = document.querySelector("iframe");

iFrame.onload = function() {
  const head =
    document.querySelector("iframe").contentWindow.document.head ||
    document
      .querySelector("iframe")
      .contentWindow.document.querySelector("head");
  const style = document.createElement("style");
  style.type = "text/css";

  if (style.styleSheet) {
    style.styleSheet.cssText = cursorCss;
  } else {
    style.appendChild(document.createTextNode(cursorCss));
  }

  head.appendChild(style);
};

// default
aGroup[0].classList.add("on");
iFrame.src = aGroup[0].baseURI + aGroup[0].getAttribute("data-src");
updateDoc(aGroup[0]);
verifyIframe(aGroup[0].getAttribute("data-src"));

for (let i = 0; i < aGroup.length; i++) {
  aGroup[i].addEventListener(
    "click",
    function(e) {
      e.preventDefault();

      // iframe src
      iFrame.src =
        e.target.baseURI + e.target.getAttribute("data-src") || "index.html";

      // doc
      updateDoc(e.target);

      // list style
      clearClass(aGroup, "on");
      e.target.classList.add("on");

      verifyIframe(e.target.getAttribute("data-src"));
    },
    false
  );
}

function updateDoc(element) {
  for (let key in DOC_OBJECT) {
    if (new RegExp(key, "ig").test(element.getAttribute("data-src"))) {
      docElement.innerHTML = converter.makeHtml(DOC_OBJECT[key]);
    }
  }
}

function clearClass(element, classname) {
  for (let i = 0; i < element.length; i++) {
    element[i].classList.remove(classname);
  }
}

/**
 * 将introduce放到第一个位置
 */
function resort(arr) {
  if (Array.isArray(arr)) {
    return arr.reduce(function(result, item) {
      if (/introduce/gi.test(item)) {
        result.unshift(item);
      } else {
        result.push(item);
      }
      return result;
    }, []);
  }
}

/**
 * 转换成对象数组
 * @param {array} arr [ "src/introduce/example.html", ... ]
 * @return {array} [ { src: 'introduce.html', label: 'Introduce' }, ... ]
 */
function toObjectArr(arr) {
  if (Array.isArray(arr)) {
    return arr.reduce(function(result, item) {
      let tmp = {};
      tmp.src = item
        .split("/")
        [item.split("/").length - 1].replace(/example/gi, item.split("/")[1]);
      tmp.label = item
        .split("/")[1]
        .replace(/([A-Z])/g, " $1")
        .replace(/^./, str => str.toUpperCase());
      result.push(tmp);

      return result;
    }, []);
  }
}

function verifyIframe(str) {
  if (/introduce/gi.test(str)) {
    document.querySelector(".devices").style.display = "none";
  } else {
    document.querySelector(".devices").style.display = "block";
  }
}
