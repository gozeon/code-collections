import {clear} from './command';

const {Terminal} = window.require('xterm');
import * as fit from 'xterm/lib/addons/fit/fit';

Terminal.applyAddon(fit);

const el = document.querySelector('#xterm');
export const xterm = new Terminal({
  theme: {
    foreground: '#ffffff',
    background: '#2f2f2f',
    cursor: '#ffffff',
    selection: 'rgba(255, 255, 255, 0.3)',
    black: '#000000',
    red: '#e06c75',
    brightRed: '#e06c75',
    green: '#A4EFA1',
    brightGreen: '#A4EFA1',
    brightYellow: '#EDDC96',
    yellow: '#EDDC96',
    magenta: '#e39ef7',
    brightMagenta: '#e39ef7',
    cyan: '#5fcbd8',
    brightBlue: '#5fcbd8',
    brightCyan: '#5fcbd8',
    blue: '#5fcbd8',
    white: '#d0d0d0',
    brightBlack: '#808080',
    brightWhite: '#ffffff'
  }
});
xterm.open(el);
xterm.focus();
xterm.fit();

hide();

el.querySelector('.clear').addEventListener('click', (e) => {
  xterm.reset();
}, false);

el.querySelector('.close').addEventListener('click', (e) => {
  hide();
}, false);

export function show() {
  [el, el.querySelector('.clear'), el.querySelector('.close')].forEach(ele => {
    ele.classList.remove('hide');
    ele.classList.add('show');
  });
}

export function hide() {
  [el, el.querySelector('.clear'), el.querySelector('.close')].forEach(ele => {
    ele.classList.remove('show');
    ele.classList.add('hide');
  });
}


