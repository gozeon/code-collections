// show(content,[btn],[success]）
// content:alert文字内容(必选)
// [btn]:确认按钮文字(可选，默认为‘知道了’)
// [success]:点击按钮回掉函数(可选，默认为隐藏alert弹框)

export class Alert {
  constructor() {
    this._iosAlertBox = document.createElement("div");
    this._iosMask = document.createElement("div");
    this._singleton = 0;
    this._init();
  }

  _init() {
    this._iosAlertBox.style.display = "none";

    this._iosMask.classList.add("aio-mask");

    let iosAlert = document.createElement("div");
    iosAlert.classList.add("ios-Alert");

    let iosAlertDb = document.createElement("div");
    iosAlertDb.classList.add("ios-Alert-bd");

    let iosAlertFt = document.createElement("div");
    iosAlertFt.classList.add("ios-Alert-ft");

    let iosConfirm = document.createElement("a");
    iosConfirm.href = "javascript:;";
    iosConfirm.classList.add("ios-Alert-btn", "ios-Alert-btn-primary");

    iosAlertFt.appendChild(iosConfirm);

    iosAlert.append(iosAlertDb, iosAlertFt);

    this._iosAlertBox.append(this._iosMask, iosAlert);

    document.body.appendChild(this._iosAlertBox);
  }

  show(content, btn = "知道了", success) {
    document.getElementsByClassName("ios-Alert-bd")[0].innerText = content;

    document.getElementsByClassName("ios-Alert-btn")[0].innerText = btn;

    if (this._iosAlertBox.style.display != "none") {
      return;
    }
    this._iosAlertBox.style.display = "block";

    this._iosAlertBox.classList.remove("aio-animate-fade-out");
    this._iosAlertBox.classList.add("aio-animate-fade-in");

    if (this._singleton == 0) {
      this._singleton = 1;
      if (typeof success == "function") {
        document
          .getElementsByClassName("ios-Alert-btn")[0]
          .addEventListener("click", success);
        document
          .getElementsByClassName("ios-Alert-btn")[0]
          .addEventListener("click", () => this.hide());
      } else
        document
          .getElementsByClassName("ios-Alert-btn")[0]
          .addEventListener("click", () => this.hide());
    }
  }

  hide() {
    this._iosAlertBox.classList.remove("aio-animate-fade-in");
    this._iosAlertBox.classList.add("aio-animate-fade-out");
    setTimeout(() => (this._iosAlertBox.style.display = "none"), 300);
  }
}
