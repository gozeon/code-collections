import {AfterContentInit, ChangeDetectorRef, Component, Inject, Input, OnInit, ViewChild} from '@angular/core';
import {commonTask, installModules} from '../../utils/command';
import {existsFile} from '../../utils/fs';
import {show} from '../../utils/xterm';
import {ToastrService} from 'ngx-toastr';

@Component({
  selector: 'app-node-modules-button-group',
  templateUrl: './node-modules-button-group.component.html',
  styleUrls: ['./node-modules-button-group.component.scss']
})
export class NodeModulesButtonGroupComponent implements OnInit {
  @Input() path: string;
  status = {};

  constructor(public toastr: ToastrService,
              public changeDetectorRef: ChangeDetectorRef) {
  }

  ngOnInit() {
  }

  existNM(path: string) {
    return existsFile(path, 'node_modules');
  }

  install(renew: boolean = false) {
    this.status[this.path] = true;

    const i = installModules(this.path, renew).pty;

    i.on('exit', (exitCode: number, signal?: number) => {
      // TODO: 有待进一步研究，目前 on('err') no working;
      if (exitCode !== 0) {
        // this.toastr.error(`Error in run install, please see log`);
        this.status[this.path] = null;
      } else {
        this.status[this.path] = null;
      }

      this.changeDetectorRef.detectChanges();
    });
  }

  showLog() {
    show();
  }
}
