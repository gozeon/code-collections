import {Component, Input, OnInit} from '@angular/core';
import {ModalService} from '../dialog/dialog.component';

@Component({
  selector: 'app-modal-content',
  templateUrl: './modal-content.component.html',
  styleUrls: ['./modal-content.component.scss']
})
export class ModalContentComponent {
  @Input() modalId;

  constructor(public modalService: ModalService) {
  }

  closeModal(id: string) {
    this.modalService.close(id);
  }
}
