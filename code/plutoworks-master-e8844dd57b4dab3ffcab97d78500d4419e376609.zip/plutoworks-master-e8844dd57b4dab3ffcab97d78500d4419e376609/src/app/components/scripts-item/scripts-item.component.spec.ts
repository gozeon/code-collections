import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ScriptsItemComponent } from './scripts-item.component';

describe('ScriptsItemComponent', () => {
  let component: ScriptsItemComponent;
  let fixture: ComponentFixture<ScriptsItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ScriptsItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScriptsItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
