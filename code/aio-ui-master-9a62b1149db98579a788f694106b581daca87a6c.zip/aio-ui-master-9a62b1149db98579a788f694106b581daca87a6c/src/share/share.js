// show(menu）
// meun:菜单数组(必选，array类型)

export class Share {
  constructor(opts) {
    this._successCallback;
    this._whiteList = ["app.jiudingcapital.com", "app.jiudingcapital.cn"];
    // 黑名单，已被封的域名或者不建议使用的域名
    this._blackList = [
      "app.jiedaibao.com",
      // app.jiedaibao.com.cn域名为正式备用域名，不建议做为分享域名
      "app.jiedaibao.com.cn"
    ];
    // 分享组件模版
    this._shareTemplate = {
      header:
        '<div id="shareMask"></div><div id="shareModal" class="share-modal"><div class="invite-title">分享</div><div class="invite-content"><div class="overflowx">',
      content: "",
      footer:
        '</div></div><div class="invite-bottom clearfix"><button id="cancel">取消</button></div></div>'
    };
    // 分享渠道与样式class对应map
    this._type2class = {
      sms: "s1",
      wxfeed: "s2",
      wxmsg: "s3",
      qq: "s4",
      qqzone: "s5",
      weibo: "s6"
    };
    // 分享渠道与渠道名称对应map
    this._type2name = {
      sms: "短信",
      wxfeed: "朋友圈",
      wxmsg: "微信",
      qq: "QQ",
      qqzone: "QQ空间",
      weibo: "微博"
    };

    if (opts.successCallback) {
      this._successCallback = opts.successCallback;
    }

    this._init(opts);
  }

  _init(opts) {
    const that = this;
    /**
     *	json转成url参数
     *	@param {Object} json json对象
     *	@return {String} url参数
     */
    let parseJsonToUrl = function(json) {
      if (!json || json == {}) {
        return "";
      }
      let arr = [];
      let str = "";
      for (let i in json) {
        str = i + "=" + json[i];
        arr.push(str);
      }
      return "?" + arr.join("&");
    };
    /**
     *	获取分享图片url
     *	@param {Object} opts 配置参数
     *	@return {String} 分享图片url
     */
    let getShareImageUrl = function(opts) {
      let imgurl = opts.shareImg || "img/notMin/jdb_icon.jpg";
      if (!imgurl) {
        return;
      }
      if (/\s*http/.test(imgurl)) {
        return imgurl;
      }
      let origin = location.origin;
      let pathName = location.pathname;
      let projectName = pathName.substring(
        0,
        pathName.substr(1).indexOf("/") + 1
      );
      projectName = projectName == "/partials" ? "" : projectName;
      return origin + projectName + "/" + imgurl;
    };
    /**
     *	获取分享url链接
     *	@param {Object} opts 配置参数
     *	@return {String} 分享url链接
     */
    let getShareUrl = function(opts) {
      let shareUrl = opts.shareUrl;

      if (!shareUrl) {
        return;
      }
      let paramsStr = parseJsonToUrl(opts.shareUrlParams);
      if (/\s*http/.test(shareUrl)) {
        return shareUrl + paramsStr;
      }
      let host = location.host;
      let origin = location.origin;
      let pathName = location.pathname;
      let projectName = pathName.substring(
        0,
        pathName.substr(1).indexOf("/") + 1
      );
      if (that._blackList.indexOf(host) > -1) {
        let enabledHost =
          that._whiteList[Math.floor(that._whiteList.length * Math.random())];
        origin = origin
          .replace(host, enabledHost)
          // 目前whiteList中的域名不支持https
          .replace("https://", "http://");
      }
      projectName = projectName == "/partials" ? "" : projectName;
      return origin + projectName + "/" + shareUrl + paramsStr;
    };
    that._shareData = {};
    let ShareFriends = ShareFriends || {};
    /**
     *  初始化分享组件配置
     *	@param {Object} opts 配置参数
     */

    opts = opts || {};
    let contentArr = [];
    let shareImageUrl = getShareImageUrl(opts);
    let sharePageUrl = getShareUrl(opts);

    for (let key in this._type2name) {
      let type = key;
      let name = this._type2name[type];
      let shareContent = opts.shareContent;
      if (shareContent[type]) {
        this._shareData[type] = {
          type: type,
          shareTitle: shareContent[type].shareTitle,
          // {{shareUrl}}替换成处理后的分享链接
          shareText: shareContent[type].shareText.replace(
            "{{shareUrl}}",
            sharePageUrl
          ),
          shareImageUrl: shareImageUrl,
          sharePageUrl: sharePageUrl,
          recipients: "",
          subject: type,
          name: name
        };
        contentArr.push(
          [
            '<div class="invite-item" data-type="' + type + '">',
            '<i class="share-icon ' + this._type2class[type] + '"></i>',
            '<div class="share-method">' + name + "</div></div>"
          ].join("")
        );
      }
    }

    this._shareTemplate.content = contentArr.join("");
  }
  /**
   *  调用Native的Schema执行分享操作
   *	@param {String} type 分享渠道
   */
  doShare(type) {
    let source = "h5app";
    let shareStr = JSON.stringify(this._shareData[type]);
    let shareContentB64 = window.encodeURIComponent(shareStr);
    let shareUrl = [
      "http://native.jiedaibao.com/web2Native/share?source=",
      source,
      "&shareTo=",
      type,
      "&content=",
      shareContentB64
    ].join("");
    window.location.href = shareUrl;
    if (this._successCallback) {
      this._successCallback();
    }
    // window.location.replace(shareUrl);
  }
  /**
   *  绑定分享事件
   */
  bind() {
    this._mask = document.getElementById("shareMask");
    this._shareModal = document.getElementById("shareModal");
    for (
      let index = 0;
      index < document.querySelectorAll("#shareModal .invite-item").length;
      index++
    ) {
      document
        .querySelectorAll("#shareModal .invite-item")
        [index].addEventListener("click", e => {
          let type = e.currentTarget.getAttribute("data-type");
          this.doShare(type);
        });
    }
    this._mask.addEventListener("click", () => {
      this.hide();
    });
    document.getElementById("cancel").addEventListener("click", () => {
      this.hide();
    });
  }
  /**
   *  显示分享窗口
   */
  open() {
    this._shareModal = document.getElementById("shareModal");
    if (!this._shareModal) {
      let html = [
        this._shareTemplate.header,
        this._shareTemplate.content,
        this._shareTemplate.footer
      ].join("");
      let temp = document.createElement("div");
      temp.innerHTML = html;
      let frag = document.createDocumentFragment();
      while (temp.firstChild) {
        frag.appendChild(temp.firstChild);
      }
      document.body.appendChild(frag);
      this.bind();
      this.show();
    } else {
      this.show();
    }
  }
  show() {
    this._mask.classList.remove("aio-animate-fade-out");
    this._shareModal.classList.remove("aio-animate-slide-down");
    this._mask.classList.add("aio-animate-fade-in");

    this._shareModal.classList.add("aio-animate-slide-up");
  }
  hide() {
    this._mask.classList.add("aio-animate-fade-out");
    this._mask.classList.remove("aio-animate-fade-in");
    this._shareModal.classList.add("aio-animate-slide-down");
    this._shareModal.classList.remove("aio-animate-slide-up");
  }
}
