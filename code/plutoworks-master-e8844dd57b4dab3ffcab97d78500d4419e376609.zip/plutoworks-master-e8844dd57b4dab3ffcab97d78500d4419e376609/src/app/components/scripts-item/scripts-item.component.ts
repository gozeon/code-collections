import {ChangeDetectorRef, Component, Input, OnInit} from '@angular/core';
import {runScripts} from '../../utils/command';
import {ToastrService} from 'ngx-toastr';

@Component({
  selector: 'app-scripts-item',
  templateUrl: './scripts-item.component.html',
  styleUrls: ['./scripts-item.component.scss']
})
export class ScriptsItemComponent implements OnInit {
  @Input() name: string;
  @Input() path: string;
  status = {};

  constructor(public toastr: ToastrService,
              public changeDetectorRef: ChangeDetectorRef) {
  }

  ngOnInit() {
  }

  runScripts(name: string, path: string) {
    this.status[path] = 'running';

    const p = runScripts(name, path).pty;

    p.on('exit', (exitCode: number, signal?: number) => {
      if (exitCode !== 0) {
        this.status[path] = 'error';
        // next line: 先注释掉，不是实时的弹出，而是点击的时候才会弹出来
        // this.toastr.error(`Error in run install, please see log`);
      } else {
        this.status[path] = 'success';
      }
      this.changeDetectorRef.detectChanges();
    });

  }
}
