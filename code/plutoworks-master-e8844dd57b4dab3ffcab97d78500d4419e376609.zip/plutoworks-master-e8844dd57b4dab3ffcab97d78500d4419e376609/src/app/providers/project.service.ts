import { Injectable } from '@angular/core';
import { Project } from '../model/project';

interface UpdateProjectOptions {
  name?: string;
  path?: string;
}

@Injectable()
export class ProjectService {

  constructor() {
  }

  insertOne(project: Project, callback?: (bool) => void) {
    const oldData = this._get();

    if (oldData.map(i => i.path).indexOf(project.path) !== -1) {
      if (callback) {
        callback(false);
      }
      return;
    }

    oldData.unshift(project);
    this._save(oldData);

    if (callback) {
      callback(true);
    }
  }

  getAll() {
    return this._get();
  }

  findById(id: string) {
    return this._get().find(item => item.id === id);
  }

  updateById(id: string, options: UpdateProjectOptions) {
    return this._get().map(item => {
      if (item.id === id) {
        return Object.assign({}, item, options, {id: id});
      }
      return item;
    });
  }

  deleteById(id: string) {
    const data = this._get().filter(item => item.id !== id);
    this._save(data);
  }

  _save(arr: any[]) {
    localStorage.setItem('project', JSON.stringify(arr));
  }

  _get() {
    return JSON.parse(localStorage.getItem('project')) || [];
  }
}
