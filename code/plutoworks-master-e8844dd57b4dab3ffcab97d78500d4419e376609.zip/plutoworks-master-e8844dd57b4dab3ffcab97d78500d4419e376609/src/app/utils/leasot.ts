import {getFilesByGlob} from './glob';

const leasot = window.require('leasot');
const path = window.require('path');
const fs = window.require('fs');

function parseFiles(files: string[]) {
  let todos = [];

  files.forEach(i => {
    const todo = leasot.parse({
      ext: path.extname(i),
      content: fs.readFileSync(i, 'utf8'),
      fileName: i
    });
    todos = todos.concat(todo);
  });

  return todos;
}

function reporterTodos(todos: any[], reporter = 'json') {
  // leasot.reporter => string
  return JSON.parse(leasot.reporter(todos, {
    reporter: 'json',
    spacing: 2
  }));
}

function formatTodos(todos: any[]) {
  const t = {};

  todos.forEach(item => {
    const a = t[item.file] || [];

    t[item.file] = a.concat([item]);
  });

  return t;
}

export function getTodosByLeasot(projectPath: string) {
  return new Promise((resolve, reject) => {
    getFilesByGlob(projectPath).then((files: string[]) => {
      if (files.length === 0) {
        resolve(files);
      } else {
        const todos = formatTodos(reporterTodos(parseFiles(files)));
        resolve(todos);
      }
    }).catch(err => {
      reject(err);
    });
  });
}
