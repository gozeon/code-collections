const path = window.require('path');
const fs = window.require('fs');
const git = window.require('simple-git');
const rimraf = window.require('rimraf');

export function gitClone(gitPath: string, targetPath: string, branch: string = 'master', rmGit: boolean = true): Promise<any> {
  return new Promise((resolve, reject) => {
    if (fs.existsSync(targetPath)) {
      reject(`${targetPath} 存在`);
      return;
    }
    git().clone(gitPath, targetPath, [
      '-b', branch,
      '--depth', 1
    ], function (err) {
      if (err) {
        reject(err);
      } else {
        if (rmGit) {
          rimraf(path.join(targetPath, '.git/'), function () {
            // console.log(`delete: ${path.join(targetPath, '.git/')}`);
          });
        }
        resolve(targetPath);
      }
    });

  });
}
