import {generateId} from '../utils/id';

export class Planet {
  id: string;
  name: string;
  url: string;

  constructor(name: string, url: string) {
    this.id = generateId();
    this.name = name;
    this.url = url;
  }
}
