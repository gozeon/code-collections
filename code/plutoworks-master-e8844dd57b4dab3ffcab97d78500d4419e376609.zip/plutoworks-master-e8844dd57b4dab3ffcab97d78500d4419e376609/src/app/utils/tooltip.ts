import tippy from 'tippy.js';

export function tooltip(el) {
  tippy(el, {
    delay: 100,
    arrow: true,
    arrowType: 'round',
    size: 'large',
    duration: 500,
    animation: 'scale'
  });
}
