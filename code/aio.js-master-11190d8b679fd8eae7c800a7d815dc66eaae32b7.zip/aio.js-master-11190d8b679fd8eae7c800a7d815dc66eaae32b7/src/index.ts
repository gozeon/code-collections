import { AIOStorage } from './storage';
import { isIos, isAndroid, isPC, isWeiXin, isJdbApp, isSafari, isUC, isQQ } from './agent';
import { getJsonFromUrl, getParameterByName } from './parameter';

export type PlatformTypes = 'ios' | 'android' | 'pc';
export type WebEnvTypes = 'wx' | 'jdb' | 'safari' | 'uc' | 'qq';

/**
 * @Note must have a default, format umd、iife can return default to bind name
 */
export default class Aio {
  static Storage: AIOStorage = AIOStorage;

  static URlParam(name?: string): string | any {
    if (name) return getParameterByName(name);
    return getJsonFromUrl();
  }

  static Platform(str?: PlatformTypes): Boolean | String | PlatformTypes {
    if (str) return Aio.Platform() === str;

    if (isIos()) return 'ios';
    if (isAndroid()) return 'android';
    if (isPC()) return 'pc';
    return 'unkown';
  }

  static WebEnv(str?: WebEnvTypes): Boolean | String | WebEnvTypes {
    if (str) return Aio.WebEnv() === str;

    if (isWeiXin()) return 'wx';
    if (isJdbApp()) return 'jdb';
    if (isSafari()) return 'safari';
    if (isUC()) return 'uc';
    if (isQQ()) return 'qq';

    return 'unknow';
  }

  static Share(): string | any {}
}
