import 'zone.js/dist/zone-mix';
import 'reflect-metadata';
import '../polyfills';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient, HttpClientJsonpModule } from '@angular/common/http';
import { ToastrModule } from 'ngx-toastr';
import { AppRoutingModule } from './app-routing.module';
import { LoadingModule } from 'ngx-loading';
// NG Translate
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';

import { ElectronService } from './providers/electron.service';

import { ClickStopPropagationDirective } from './directives/click-stop-propagation.directive';

import { AppComponent } from './app.component';
import { HomeComponent } from './pages/home/home.component';
import { SettingComponent } from './pages/setting/setting.component';
import { TemplatesComponent } from './pages/templates/templates.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { TabsComponent } from './components/tabs/tabs.component';
import { TabComponent } from './components/tab/tab.component';
import { PlanetService } from './providers/planet.service';
import { TemplateCardComponent } from './components/template-card/template-card.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ProjectService } from './providers/project.service';
import { NodeModulesButtonGroupComponent } from './components/node-modules-button-group/node-modules-button-group.component';
import { TerminalComponent } from './components/terminal/terminal.component';
import { KeysPipe } from './pipe/keys.pipe';
import { ErrorBarComponent } from './components/error-bar/error-bar.component';
import { CheckPlutoYmlComponent } from './components/check-pluto-yml/check-pluto-yml.component';
import { ComponentManagerComponent } from './components/component-manager/component-manager.component';
import { PathPipe } from './pipe/path.pipe';
import { ScriptsManagerComponent } from './components/scripts-manager/scripts-manager.component';
import {CommonModule} from '@angular/common';
import { ScriptsItemComponent } from './components/scripts-item/scripts-item.component';
import {ModalComponent, ModalService} from './components/dialog/dialog.component';
import { ModalContentComponent } from './components/modal-content/modal-content.component';
import { ComponentCardComponent } from './components/component-card/component-card.component';
import { TodoManagerComponent } from './components/todo-manager/todo-manager.component';
import { EmptyPipe } from './pipe/empty.pipe';
import { AccordionItemComponent } from './components/accordion-item/accordion-item.component';
import { AccordionComponent } from './components/accordion/accordion.component';
// AoT requires an exported function for factories
export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ClickStopPropagationDirective,
    SettingComponent,
    TemplatesComponent,
    DashboardComponent,
    TabsComponent,
    TabComponent,
    TemplateCardComponent,
    NodeModulesButtonGroupComponent,
    TerminalComponent,
    KeysPipe,
    ErrorBarComponent,
    CheckPlutoYmlComponent,
    ComponentManagerComponent,
    PathPipe,
    ScriptsManagerComponent,
    ScriptsItemComponent,
    ModalComponent,
    ModalContentComponent,
    ComponentCardComponent,
    TodoManagerComponent,
    EmptyPipe,
    AccordionItemComponent,
    AccordionComponent,
  ],
  imports: [
    CommonModule,
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    HttpClientJsonpModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    LoadingModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: (HttpLoaderFactory),
        deps: [HttpClient]
      }
    })
  ],
  providers: [ElectronService, PlanetService, ProjectService, ModalService],
  bootstrap: [AppComponent]
})
export class AppModule {
}
