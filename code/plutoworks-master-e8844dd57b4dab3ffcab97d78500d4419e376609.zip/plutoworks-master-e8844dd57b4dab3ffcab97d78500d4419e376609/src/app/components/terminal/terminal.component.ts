import { Component, ElementRef, ViewChild, AfterContentInit, Input, OnInit } from '@angular/core';
import { clear } from '../../utils/command';

@Component({
  selector: 'app-terminal',
  templateUrl: './terminal.component.html',
  styleUrls: ['./terminal.component.scss']
})
export class TerminalComponent implements AfterContentInit {
  @Input() show: Boolean;
  @ViewChild('xterm') div: ElementRef;
  pty: any;

  constructor() {
  }

  ngAfterContentInit() {
  }

  run(command: string) {
    this.pty.write(command + '\r');
  }

  clear() {
    this.run(clear);
  }

  close() {
    this.show = false;
  }
}
