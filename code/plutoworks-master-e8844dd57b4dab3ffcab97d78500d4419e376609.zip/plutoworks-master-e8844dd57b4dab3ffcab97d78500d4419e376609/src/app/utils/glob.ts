import {promise} from 'selenium-webdriver';

const glob = window.require('glob');
// tslint:disable-next-line
const parseType = 'bash|c|cjsx|coffee|cpp|cr|cs|cson|css|ejs|erb|erl|es|es6|go|h|haml|handlebars|hbs|hgn|hogan|hrl|hs|htm|html|jade|java|js|jsx|kt|less|m|mm|mustache|njk|pas|php|pl|pm|pug|py|rb|sass|scala|scss|sh|sql|ss|styl|swift|ts|tsx|twig|vue|yaml|zsh';

function deleteLastChar(path: string): string {
  if (!path) {
    throw new Error(`the path is ${path}`);
  }

  if (path.endsWith('/')) {
    return path.slice(0, -1);
  }

  return path;
}

function createRegex(path: string) {
  path = deleteLastChar(path);

  return `${path}/**/*.*(${parseType})`;
}

function createIgnoreNodeModules(path: string) {
  path = deleteLastChar(path);

  return `${path}/node_modules/**/*.*`;
}


export function getFilesByGlob(path: string) {
  return new Promise((resolve, reject) => {
    glob(createRegex(path), {dot: true, ignore: createIgnoreNodeModules(path)}, (err, files: string[]) => {
      if (err) {
        reject(err);
      }
      resolve(files);
    });
  });

}
