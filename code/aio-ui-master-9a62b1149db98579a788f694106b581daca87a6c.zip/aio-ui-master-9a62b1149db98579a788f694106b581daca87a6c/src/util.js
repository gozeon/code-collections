/**
 * javascript template engine
 * @param html    string '<div><% this.message %></div>'
 * @param options object {message: 'hello world'}
 * @returns {*}   string '<div>hello world</div>'
 * @link https://gist.github.com/gozeon/a02e12f9566adbd54fbfa2f3f654131e
 */
export function TemplateEngine(html, options) {
  var re = /<%([^%>]+)?%>/g,
    reExp = /(^( )?(if|for|else|switch|case|break|{|}))(.*)?/g,
    code = "var r=[];\n",
    cursor = 0,
    match;
  var add = function(line, js) {
    js
      ? (code += line.match(reExp) ? line + "\n" : "r.push(" + line + ");\n")
      : (code +=
          line != "" ? 'r.push("' + line.replace(/"/g, '\\"') + '");\n' : "");
    return add;
  };
  while ((match = re.exec(html))) {
    add(html.slice(cursor, match.index))(match[1], true);
    cursor = match.index + match[0].length;
  }
  add(html.substr(cursor, html.length - cursor));
  code += 'return r.join("");';
  return new Function(code.replace(/[\r\t\n]/g, "")).apply(options);
}

/**
 * 设置样式
 * @param el
 * @param style
 */
export function setStyle(el, style) {
  for (let key in style) {
    el.style[key] = style[key];
  }
}

/**
 * 生成id
 * @returns {string} short id
 */
export function generateUID() {
  // I generate the UID from two parts here
  // to ensure the random number provide enough bits.
  var firstPart = (Math.random() * 46656) | 0;
  var secondPart = (Math.random() * 46656) | 0;
  firstPart = ("000" + firstPart.toString(36)).slice(-3);
  secondPart = ("000" + secondPart.toString(36)).slice(-3);
  return firstPart + secondPart;
}

/**
 * 计算元素的translateX translateY
 * @param item element
 * @returns {*} [x, y]
 */
export function getTranslate(item) {
  var transArr = [];

  if (!window.getComputedStyle) return;
  var style = getComputedStyle(item),
    transform =
      style.transform ||
      style.webkitTransform ||
      style.mozTransform ||
      style.msTransform;
  var mat = transform.match(/^matrix3d\((.+)\)$/);
  if (mat) return parseFloat(mat[1].split(", ")[13]);

  mat = transform.match(/^matrix\((.+)\)$/);
  mat ? transArr.push(parseFloat(mat[1].split(", ")[4])) : transArr.push(0);
  mat ? transArr.push(parseFloat(mat[1].split(", ")[5])) : transArr.push(0);

  return transArr;
}
