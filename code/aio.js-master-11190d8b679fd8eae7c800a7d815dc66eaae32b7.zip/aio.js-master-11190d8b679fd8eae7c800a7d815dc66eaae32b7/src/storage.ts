export class AIOStorage {
  static setItem(key: string, value: any): void {
    localStorage.setItem(key, JSON.stringify(value));
  }

  static getItem(key: string): any {
    const result = localStorage.getItem(key);

    if (result) {
      return JSON.parse(result);
    } else {
      return null;
    }
  }

  static removeItem(key: string): void {
    localStorage.removeItem(key);
  }

  static clean(): void {
    localStorage.clear();
  }
}
