import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
  name: 'keys'
})
export class KeysPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    const keys = [];

    /* tslint:disable-next-line */
    for (const k in value) {
      keys.push(k);
    }

    if (args === 'first') {
      return keys[0];
    }

    if (args === 'del_first') {
      keys.shift();
    }

    return keys;
  }

}
