# Hello World

如何在 Aio-ui 开发一个组件

### 文档结构

```bash
# 大致目录
root
-- src
-- -- <组件名字>
-- -- -- doc.md           # 用来生成文档
-- -- -- example.html     # 模拟器使用文件
-- -- -- <组件名字>.vue
-- -- -- <组件名字>.scss
-- -- -- template.html    # 可选的html模版文件
-- -- -- ...
-- index.js               # 引入组件
-- util.js

```

### 组件方式

使用 `vue plguin` 方式

### 使用模版引擎

大部分方法组件会用到

```html
<div id="<% this.id %>" class="<% this.id %>">
  <h1><% this.message %></h1>
  <ol>
    <% if(this.show) { %>
      <% for(let key in this.list ) { %>
        <li><% this.list[key] %></li>
      <% } %>
    <% } %>
  </ol>
</div>
```

```js
import tpl from "./helloworld.html";

const data = {
  id: this.id,
  message: msg,
  show: true,
  list: ["apple", "banana", "orange"]
};

document.body.insertAdjacentHTML("beforeend", TemplateEngine(tpl, data));

document.querySelector(`#${this.id}`).style.display = "none";
```

### 其他

项目 & 文档问题和建议请发送邮件 pluto.list@jiedaibao.com
