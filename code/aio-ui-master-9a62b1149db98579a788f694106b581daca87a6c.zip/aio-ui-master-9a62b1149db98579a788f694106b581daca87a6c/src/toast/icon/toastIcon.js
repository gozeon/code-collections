// show(state,msg,[autoclose],[delay])
// state:状态（必填，默认success），
// msg:指定文字（必填，为‘’则为默认匹配文字），
// [autoclose]:是否自动取消（选填,默认自动取消），
// [delay]:取消延时ms（选填，默认2000ms）

// hide()

export class ToastIcon {
  constructor() {
    this._toastIcon = document.createElement("div");
    this._mask = document.createElement("div");
    this._init();
  }

  _init() {
    this._toastIcon.style.display = "none";

    this._mask.classList.add("aio-mask-transparent");

    let toastIconBg = document.createElement("div");
    toastIconBg.classList.add("toast-toast-icon-bg");

    this.toastIconImg = document.createElement("i");
    this.toastIconImg.classList.add("toast-icon-img");

    this._toastIconTxt = document.createElement("p");
    this._toastIconTxt.classList.add("toast-icon-txt");

    toastIconBg.append(this.toastIconImg, this._toastIconTxt);

    this._toastIcon.append(this._mask, toastIconBg);

    document.body.appendChild(this._toastIcon);
  }

  show(state = "success", msg, autoclose = true, delay = 2000) {
    if (state == "success") {
      if (!msg) msg = "已完成"; //||
      this.toastIconImg.classList.add("toast-icon-img-success");
    } else if (state == "error") {
      if (!msg) msg = "失败";
      this.toastIconImg.classList.add("toast-icon-img-error");
    } else if (state == "loading") {
      if (!msg) msg = "数据加载中";
      this.toastIconImg.classList.add("toast-icon-img-loading");
    } else {
      console.error("toast参数类型错误");
    }

    this._toastIconTxt.innerText = msg;

    if (this._toastIcon.style.display != "none") {
      return;
    }
    this._toastIcon.style.display = "block";

    this._toastIcon.classList.remove("aio-animate-fade-out");
    this._toastIcon.classList.add("aio-animate-fade-in");

    if (autoclose) this._toastIconTimer = setTimeout(() => this.hide(), delay);
  }

  hide() {
    clearTimeout(this._toastIconTimer);
    this._toastIcon.classList.remove("aio-animate-fade-in");
    this._toastIcon.classList.add("aio-animate-fade-out");
    setTimeout(() => (this._toastIcon.style.display = "none"), 300);
  }
}
