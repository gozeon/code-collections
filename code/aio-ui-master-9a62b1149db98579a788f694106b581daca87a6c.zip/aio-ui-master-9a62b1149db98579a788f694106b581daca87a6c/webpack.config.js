var path = require("path");
var fs = require("fs");
var webpack = require("webpack");
var BundleAnalyzerPlugin = require("webpack-bundle-analyzer")
  .BundleAnalyzerPlugin;
var HtmlWebpackPlugin = require("html-webpack-plugin");
var CleanWebpackPlugin = require("clean-webpack-plugin");
var merge = require("webpack-merge");
var htmlList = [];
var docList = [];
var docObject = {};

function fromDir(startPath, filter, callback) {
  if (!fs.existsSync(startPath)) {
    console.log("no dir ", startPath);
    return;
  }

  const files = fs.readdirSync(startPath);
  for (let i = 0; i < files.length; i++) {
    const filename = path.join(startPath, files[i]);
    const stat = fs.lstatSync(filename);
    if (stat.isDirectory()) {
      fromDir(filename, filter, callback); //recurse
    } else if (filter.test(filename)) callback(filename);
  }
}

var baseConf = {
  entry: "./src/index.js",
  output: {
    path: path.resolve(__dirname, "./dist"),
    filename: "aio-ui.min.js",
    libraryTarget: "umd"
  },
  module: {
    rules: [
      {
        test: /\.vue$/,
        loader: "vue-loader",
        options: {
          loaders: {
            scss: "vue-style-loader!css-loader!postcss-loader!sass-loader",
            sass:
              "vue-style-loader!css-loader!postcss-loader!sass-loader?indentedSyntax"
          }
          // other vue-loader options go here
        }
      },
      {
        test: /\.js$/,
        loader: "babel-loader",
        exclude: /node_modules/
      },
      {
        test: /\.(png|jpg|gif|svg)$/,
        loader: "url-loader"
      },
      {
        test: /\.(html|htm|md)$/,
        loader: "html-loader"
      }
    ]
  },
  resolve: {
    alias: {
      vue$: "vue/dist/vue.esm.js"
    }
  },
  performance: {
    hints: false
  },
  devtool: "#source-map"
};

var devConf = merge(baseConf, {
  devServer: {
    historyApiFallback: true,
    noInfo: true
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: "index.html",
      inject: "head"
    })
  ]
});

var prodUmdConf = merge(baseConf, {
  output: {
    path: path.resolve(__dirname, "./dist"),
    filename: "aio-ui.min.umd.js",
    libraryTarget: "umd"
  },
  plugins: [
    new webpack.optimize.UglifyJsPlugin({
      sourceMap: false,
      compress: { warnings: false },
      comments: false
    }),
    new webpack.ProvidePlugin({}),
    // new BundleAnalyzerPlugin(),
    new webpack.LoaderOptionsPlugin({
      minimize: true
    })
  ]
});

var prodCjs2Conf = merge(prodUmdConf, {
  output: {
    path: path.resolve(__dirname, "./dist"),
    filename: "aio-ui.min.cjs2.js",
    libraryTarget: "commonjs2"
  }
});

var docConf = merge(baseConf, {
  entry: {
    "aio-ui": "./src/index.js",
    doc: "./index.doc.js"
  },
  devServer: {
    historyApiFallback: true,
    noInfo: true
  },
  output: {
    path: path.join(__dirname, "./doc"),
    filename: "[name].js",
    libraryTarget: "umd"
  },
  devServer: {
    historyApiFallback: true,
    noInfo: true
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: "index.doc.html",
      chunks: ["doc"]
    })
  ]
});

if (process.env.NODE_ENV === "development") {
  module.exports = devConf;
}

if (process.env.NODE_ENV === "production:umd") {
  module.exports = prodUmdConf;
}

if (process.env.NODE_ENV === "production:cjs") {
  module.exports = prodCjs2Conf;
}

if (process.env.NODE_ENV === "doc") {
  fromDir("./src", /example(\.(ios|android))?\.html$/, function(filename) {
    htmlList.push(filename);
  });

  fromDir("./src", /doc.md$/, function(filename) {
    docList.push(filename);
  });

  docList.forEach((item, index) => {
    docObject[item.split("/")[1]] = fs.readFileSync(item, "utf-8");
  });

  const HTML_LIST = JSON.parse(JSON.stringify(htmlList));
  const definePlugin = [
    new webpack.DefinePlugin({
      HTML_LIST: JSON.stringify(HTML_LIST),
      DOC_OBJECT: JSON.stringify(docObject)
    })
  ];

  const cleanPlugin = [new CleanWebpackPlugin(["doc"])];

  htmlList.forEach((item, index) => {
    const newFilename = item
      .split("/")
      [item.split("/").length - 1].replace(/example/gi, item.split("/")[1]);
    htmlList[index] = new HtmlWebpackPlugin({
      template: path.join(__dirname, item),
      filename: newFilename,
      inject: "head",
      chunks: ["aio-ui"]
    });
  });

  docConf.plugins = docConf.plugins
    .concat(htmlList)
    .concat(definePlugin)
    .concat(cleanPlugin);

  module.exports = docConf;
}
