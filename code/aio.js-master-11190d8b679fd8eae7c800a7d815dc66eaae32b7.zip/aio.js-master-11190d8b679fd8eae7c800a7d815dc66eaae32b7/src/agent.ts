const ua = navigator.userAgent;

export function isIos(): boolean {
  return /(iPhone|iPad|iPod|iOS)/i.test(ua);
}
export function isAndroid(): boolean {
  return /(Android)/i.test(ua);
}
export function isPC(): boolean {
  // const agents = ['android', 'windows phone', 'iphone', 'ipad', 'ipod'];
  // for (let i = 0; i < agents.length; i++) {
  //   if ((ua.toLocaleLowerCase().indexOf(agents[i]) >= 0 && (document.referrer == '' || document.referrer == null)) {
  //     return true;
  //   }
  // }

  if (isAndroid() || /(iPhone|iPad|iPod|windows phone)/i.test(ua)) {
    return false;
  }

  return true;
}

export function isWeiXin(): boolean {
  return /MicroMessenger/i.test(ua);
}

export function isQQ(): boolean {
  return /qq/i.test(ua);
}

export function isUC(): boolean {
  return /UCBrowser/i.test(ua);
}

/**
 * @link https://stackoverflow.com/questions/5899783/detect-safari-using-jquery
 */
export function isSafari(): boolean {
  return /^((?!chrome|android).)*safari/i.test(ua);
}

export function isJdbApp(): boolean {
  return /jdb/i.test(ua);
}
