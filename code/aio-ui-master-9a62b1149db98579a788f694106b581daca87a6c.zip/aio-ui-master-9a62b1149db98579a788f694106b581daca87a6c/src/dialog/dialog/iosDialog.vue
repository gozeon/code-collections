<style src="./iosDialog.scss" lang="scss"> </style>
<style src='../../sass/_animate.scss' lang="scss"></style>