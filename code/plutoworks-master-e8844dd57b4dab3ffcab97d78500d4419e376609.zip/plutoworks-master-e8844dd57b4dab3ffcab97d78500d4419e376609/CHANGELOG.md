<a name="0.0.6"></a>
## [0.0.6](http://git.jdb-dev.com/plutolab/plutoworks/compare/v0.0.5...v0.0.6) (2018-08-03)


### Bug Fixes

* **component:** 添加组件名字重复问题 ([41e4d94](http://git.jdb-dev.com/plutolab/plutoworks/commits/41e4d94))
* **todo:** 解决快速切换目录，todo刷新错误 ([51220a6](http://git.jdb-dev.com/plutolab/plutoworks/commits/51220a6))
* **utils:** rename commad to command ([c0aa32c](http://git.jdb-dev.com/plutolab/plutoworks/commits/c0aa32c))



<a name="0.0.5"></a>
## [0.0.5](http://git.jdb-dev.com/plutolab/plutoworks/compare/v0.0.4...v0.0.5) (2018-07-27)


### Bug Fixes

* **template:** config default path with document ([5b42ba6](http://git.jdb-dev.com/plutolab/plutoworks/commits/5b42ba6))
* **template:** default path to format ([51385b9](http://git.jdb-dev.com/plutolab/plutoworks/commits/51385b9))


### Features

* **system:** TODO manager ([976cdcb](http://git.jdb-dev.com/plutolab/plutoworks/commits/976cdcb))



<a name="0.0.4"></a>
## [0.0.4](http://git.jdb-dev.com/plutolab/plutoworks/compare/v0.0.3...v0.0.4) (2018-07-20)


### Bug Fixes

* **system:** update check network config ([5bb0d4e](http://git.jdb-dev.com/plutolab/plutoworks/commits/5bb0d4e))
* **template:** click stop propagation ([83357e4](http://git.jdb-dev.com/plutolab/plutoworks/commits/83357e4))


### Features

* components manager ([e7ca3b0](http://git.jdb-dev.com/plutolab/plutoworks/commits/e7ca3b0))
* **component:** detect config & verify template name ([05d160f](http://git.jdb-dev.com/plutolab/plutoworks/commits/05d160f))
* **component:** whatch component config ([4b2585a](http://git.jdb-dev.com/plutolab/plutoworks/commits/4b2585a))



<a name="0.0.3"></a>
## [0.0.3](http://git.jdb-dev.com/plutolab/plutoworks/compare/v0.0.2...v0.0.3) (2018-07-15)


### Bug Fixes

* see issure 10 ([bc02b67](http://git.jdb-dev.com/plutolab/plutoworks/commits/bc02b67))
* **scripts:** fix process env path ([f94db27](http://git.jdb-dev.com/plutolab/plutoworks/commits/f94db27))


### Features

* **system:** check network ([e0ff8b7](http://git.jdb-dev.com/plutolab/plutoworks/commits/e0ff8b7))
* **system:** update prompt ([3205f75](http://git.jdb-dev.com/plutolab/plutoworks/commits/3205f75))



<a name="0.0.2"></a>
## [0.0.2](http://git.jdb-dev.com/plutolab/plutoworks/compare/v0.0.1...v0.0.2) (2018-07-06)


### Features

* **router:** component reuse with router ([6f554ff](http://git.jdb-dev.com/plutolab/plutoworks/commits/6f554ff))



<a name="0.0.1"></a>
## [0.0.1](http://git.jdb-dev.com/plutolab/plutoworks/compare/fd303b6...v0.0.1) (2018-07-06)


### Bug Fixes

* **process:** replace node-pty to process ([f23c933](http://git.jdb-dev.com/plutolab/plutoworks/commits/f23c933))


### Features

* **manager:** script manager instead task manager ([fd303b6](http://git.jdb-dev.com/plutolab/plutoworks/commits/fd303b6))
* **system:** add view menu ([f681c82](http://git.jdb-dev.com/plutolab/plutoworks/commits/f681c82))
* **system:** copy & paste ([ec479a5](http://git.jdb-dev.com/plutolab/plutoworks/commits/ec479a5))



